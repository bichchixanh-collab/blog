# Full audit — V3 Supabase

| Hạng mục | Trạng thái |
|---|---|
| Pet/Bingo | FIXED / REMOVED |
| user_stats bingo/pet_xp data-loss bug | REMOVED with feature |
| One-time ticket | FIXED: jti + Supabase atomic consume |
| GitHub as mutable database | REMOVED from runtime |
| Download counter concurrency | FIXED with SQL atomic upsert |
| Economy double-spend | FIXED with PostgreSQL row lock/RPC |
| Economy guest identity | IMPROVED: signed HttpOnly guest cookie |
| Comment name spoofing for new comments | FIXED: uid/guest_key identity |
| Duplicate comments | Added 24h duplicate guard |
| SSR rating stale JSON | FIXED: Supabase query |
| Migration `err/error` | FIXED |
| Migration conflict keys | FIXED in current import script |
| Gate data `none` with stale fields | CLEANED |
| Automated syntax/validation/smoke tests | ADDED |
| XAMPP routing | PRESERVED/FIXED in V2 |
| CSP / inline JS | NOT fully removed because current UI still relies on inline scripts; `unsafe-inline` remains intentionally |
| Upstash rate-limit | KEPT as recommended production dependency |
| Assets | NOT treated as a defect; intentionally omitted from lightweight ZIP |

## Production setup

Run `supabase/schema.sql`, then `npm run migrate` with Supabase environment variables. Runtime mutable data no longer needs a GitHub PAT.
