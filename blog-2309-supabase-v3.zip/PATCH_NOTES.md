# Production hardening — Supabase SQL + Pet/Bingo removal

## Đã sửa
- Loại bỏ Pet/Bingo khỏi hệ thống gate, stats và migration.
- Runtime mutable data chuyển khỏi GitHub JSON:
  - comments → `public.comments`
  - user stats → `public.user_stats`
  - download counters → `public.game_downloads`
  - economy wallet → `public.wallets` + `wallet_owned` + `wallet_bonus`
  - one-time download tickets → `public.used_tickets`
- Download counter dùng SQL `ON CONFLICT` atomic, không còn read-modify-write GitHub.
- Economy check-in/purchase/bonus dùng PostgreSQL transaction/row lock, tránh double-spend khi request đồng thời.
- Ticket dùng `jti` + SQL atomic consume, fail-closed khi Supabase không khả dụng.
- Guest economy/comment identity dùng signed HttpOnly cookie thay cho chỉ tin `localStorage` CID.
- Comment mới lưu `uid` hoặc guest key; gate comment của user không còn phụ thuộc tên hiển thị nếu đã có identity.
- Chống duplicate comment trong 24 giờ cho cùng identity/game/text.
- SSR rating đọc Supabase thay vì đọc `data/comments.json` cũ.
- Migration script import dữ liệu JSON hiện có vào Supabase, idempotent.
- Thêm SQL schema và RPC functions.
- Thêm smoke tests + syntax/validation test command.
- Giữ XAMPP routing `.htaccess` và các file game vật lý.

## Không coi `assets/` là lỗi
ZIP source này không chứa thư mục `assets/` theo yêu cầu đóng gói nhẹ. Các file HTML vẫn giữ nguyên đường dẫn assets; khi deploy chỉ cần đặt lại thư mục assets thật vào root project.

## Biến môi trường production
- `SUPABASE_URL`
- `SUPABASE_SERVICE_KEY`
- `SUPABASE_JWT_SECRET` nếu dùng HS256; ES256 dùng JWKS của Supabase
- `LOCK_SECRET` (>=16 ký tự, nên dùng chuỗi ngẫu nhiên dài)
- `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN` vẫn khuyến nghị cho rate-limit bền qua nhiều instance
- `TURNSTILE_SECRET` nếu bật Cloudflare Turnstile
- `SITE_URL`

`GITHUB_TOKEN`, `GITHUB_REPO`, `GITHUB_BRANCH` không còn là dependency runtime cho comments/stats/economy.
