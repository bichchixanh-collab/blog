const crypto=require('crypto');
const {bearerToken,verifySbTokenAsync}=require('./_sb');
function cookie(req,name){const raw=String(req.headers?.cookie||'');const m=raw.match(new RegExp('(?:^|;\\s*)'+name+'=([^;]+)'));return m?decodeURIComponent(m[1]):'';}
function signedGuest(req,res){const raw=cookie(req,'j2me_guest');const secret=String(process.env.LOCK_SECRET||'');if(secret.length<16)return '';if(raw){const [id,sig]=raw.split('.');if(/^[a-f0-9]{64}$/.test(id)&&sig){const want=crypto.createHmac('sha256',secret).update('guest:'+id).digest('hex');if(sig.length===want.length&&crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(want)))return 'g_'+id;}}
const id=crypto.randomBytes(32).toString('hex');const sig=crypto.createHmac('sha256',secret).update('guest:'+id).digest('hex');res.setHeader('Set-Cookie',`j2me_guest=${id}.${sig}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax; Secure`);return 'g_'+id;}
async function identity(req,res){const me=await verifySbTokenAsync(bearerToken(req));return me?{uid:me.uid,key:'u_'+me.uid,me}:{uid:null,key:signedGuest(req,res),me:null};}
module.exports={identity};
