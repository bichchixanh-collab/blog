-- J2ME.VERCEL.APP production schema
-- Run in Supabase SQL Editor with the service-role key kept server-side.
create extension if not exists pgcrypto;

create table if not exists public.user_stats (
  uid uuid primary key,
  minutes integer not null default 0 check (minutes >= 0),
  likes text[] not null default '{}',
  completed text[] not null default '{}',
  updated_at timestamptz not null default now()
);

create table if not exists public.comments (
  id text primary key,
  game_id text not null,
  name varchar(30) not null,
  stars smallint not null default 5 check (stars between 0 and 5),
  text varchar(500) not null,
  status varchar(16) not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  parent_id text references public.comments(id) on delete cascade,
  uid uuid null,
  guest_key text null,
  mod_reason varchar(160) null
);
create index if not exists comments_game_status_created_idx on public.comments(game_id,status,created_at desc);
create index if not exists comments_uid_status_idx on public.comments(uid,status);
create index if not exists comments_guest_status_idx on public.comments(guest_key,status);

create table if not exists public.game_downloads (
  game_id text primary key,
  downloads bigint not null default 0 check (downloads >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.wallets (
  owner_key text primary key,
  user_id uuid null,
  balance integer not null default 0 check (balance >= 0),
  last_checkin date null,
  streak integer not null default 0 check (streak between 0 and 3650),
  updated_at timestamptz not null default now()
);
create index if not exists wallets_user_id_idx on public.wallets(user_id);

create table if not exists public.wallet_owned (
  owner_key text not null references public.wallets(owner_key) on delete cascade,
  game_id text not null,
  created_at timestamptz not null default now(),
  primary key(owner_key,game_id)
);

create table if not exists public.wallet_bonus (
  owner_key text not null references public.wallets(owner_key) on delete cascade,
  comment_id text not null,
  amount integer not null check(amount > 0),
  created_at timestamptz not null default now(),
  primary key(owner_key,comment_id)
);


create table if not exists public.used_tickets (
  jti text primary key,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index if not exists used_tickets_expires_idx on public.used_tickets(expires_at);
alter table public.used_tickets enable row level security;
create or replace function public.consume_ticket(p_jti text,p_expires_at timestamptz)
returns boolean language plpgsql security definer set search_path=public as $$
begin
  if p_expires_at <= now() then return false; end if;
  insert into used_tickets(jti,expires_at) values(p_jti,p_expires_at) on conflict(jti) do nothing;
  return found;
end $$;

-- Only the server service role should access these tables directly.
alter table public.user_stats enable row level security;
alter table public.comments enable row level security;
alter table public.game_downloads enable row level security;
alter table public.wallets enable row level security;
alter table public.wallet_owned enable row level security;
alter table public.wallet_bonus enable row level security;

create or replace function public.user_stats_event(p_uid uuid,p_event text,p_id text default null)
returns public.user_stats language plpgsql security definer set search_path=public as $$
declare r public.user_stats; now_ts timestamptz:=now(); last_ts timestamptz;
begin
  insert into user_stats(uid) values(p_uid) on conflict(uid) do nothing;
  select * into r from user_stats where uid=p_uid for update;
  if p_event='heartbeat' then
    last_ts:=coalesce(r.updated_at,'epoch'::timestamptz);
    if extract(epoch from (now_ts-last_ts)) >= 50 then r.minutes:=least(r.minutes+1,100000); end if;
  elsif p_event in ('like','unlike') then
    if p_id is null or p_id !~ '^[A-Za-z0-9-]{1,120}$' then return r; end if;
    if p_event='like' then r.likes:=array( select distinct x from unnest(array_append(r.likes,p_id)) x limit 500 );
    else r.likes:=array( select x from unnest(r.likes) x where x<>p_id limit 500 ); end if;
  elsif p_event in ('complete','uncomplete') then
    if p_id is null or p_id !~ '^[A-Za-z0-9-]{1,120}$' then return r; end if;
    if p_event='complete' then r.completed:=array( select distinct x from unnest(array_append(r.completed,p_id)) x limit 500 );
    else r.completed:=array( select x from unnest(r.completed) x where x<>p_id limit 500 ); end if;
  else return r;
  end if;
  r.updated_at:=now_ts;
  update user_stats set minutes=r.minutes,likes=r.likes,completed=r.completed,updated_at=r.updated_at where uid=p_uid;
  return r;
end $$;

create or replace function public.increment_download(p_game_id text)
returns bigint language plpgsql security definer set search_path=public as $$
declare n bigint;
begin
  insert into game_downloads(game_id,downloads) values(p_game_id,1)
  on conflict(game_id) do update set downloads=game_downloads.downloads+1,updated_at=now()
  returning downloads into n;
  return n;
end $$;

create or replace function public.wallet_checkin(p_owner_key text,p_user_id uuid,p_day date,p_amount integer)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w wallets; got integer; bonus integer:=0; new_streak integer;
begin
  insert into wallets(owner_key,user_id) values(p_owner_key,p_user_id) on conflict(owner_key) do nothing;
  select * into w from wallets where owner_key=p_owner_key for update;
  if w.last_checkin=p_day then return jsonb_build_object('got',0,'bonus',0,'balance',w.balance,'streak',w.streak); end if;
  if w.last_checkin=p_day-1 then new_streak:=least(w.streak+1,3650); else new_streak:=1; end if;
  got:=greatest(5,least(10,p_amount));
  if new_streak % 7 = 0 then bonus:=15; elsif new_streak % 3 = 0 then bonus:=5; end if;
  update wallets set balance=balance+got+bonus,last_checkin=p_day,streak=new_streak,updated_at=now(),user_id=coalesce(p_user_id,user_id) where owner_key=p_owner_key returning * into w;
  return jsonb_build_object('got',got,'bonus',bonus,'balance',w.balance,'streak',w.streak);
end $$;

create or replace function public.wallet_purchase(p_owner_key text,p_user_id uuid,p_game_id text,p_cost integer)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w wallets;
begin
  insert into wallets(owner_key,user_id) values(p_owner_key,p_user_id) on conflict(owner_key) do nothing;
  select * into w from wallets where owner_key=p_owner_key for update;
  if exists(select 1 from wallet_owned where owner_key=p_owner_key and game_id=p_game_id) then return jsonb_build_object('ok',true,'owned',true,'balance',w.balance); end if;
  if w.balance < p_cost then return jsonb_build_object('ok',false,'reason','low_exp','need',p_cost,'balance',w.balance); end if;
  update wallets set balance=balance-p_cost,updated_at=now(),user_id=coalesce(p_user_id,user_id) where owner_key=p_owner_key returning * into w;
  insert into wallet_owned(owner_key,game_id) values(p_owner_key,p_game_id) on conflict do nothing;
  return jsonb_build_object('ok',true,'owned',false,'balance',w.balance);
end $$;

create or replace function public.wallet_credit_bonus(p_owner_key text,p_user_id uuid,p_comment_id text,p_amount integer)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w wallets; a integer:=greatest(1,least(50,p_amount));
begin
  insert into wallets(owner_key,user_id) values(p_owner_key,p_user_id) on conflict(owner_key) do nothing;
  if exists(select 1 from wallet_bonus where owner_key=p_owner_key and comment_id=p_comment_id) then return jsonb_build_object('credited',false,'reason','done'); end if;
  insert into wallet_bonus(owner_key,comment_id,amount) values(p_owner_key,p_comment_id,a);
  update wallets set balance=balance+a,updated_at=now(),user_id=coalesce(p_user_id,user_id) where owner_key=p_owner_key returning * into w;
  return jsonb_build_object('credited',true,'amount',a,'balance',w.balance);
end $$;


-- V4 hardening: RPCs are server-only. Supabase service role calls them through REST;
-- anon/authenticated clients must not be able to invoke wallet/stats mutations directly.
revoke all on function public.consume_ticket(text,timestamptz) from public, anon, authenticated;
revoke all on function public.user_stats_event(uuid,text,text) from public, anon, authenticated;
revoke all on function public.increment_download(text) from public, anon, authenticated;
revoke all on function public.wallet_checkin(text,uuid,date,integer) from public, anon, authenticated;
revoke all on function public.wallet_purchase(text,uuid,text,integer) from public, anon, authenticated;
revoke all on function public.wallet_credit_bonus(text,uuid,text,integer) from public, anon, authenticated;
grant execute on function public.consume_ticket(text,timestamptz) to service_role;
grant execute on function public.user_stats_event(uuid,text,text) to service_role;
grant execute on function public.increment_download(text) to service_role;
grant execute on function public.wallet_checkin(text,uuid,date,integer) to service_role;
grant execute on function public.wallet_purchase(text,uuid,text,integer) to service_role;
grant execute on function public.wallet_credit_bonus(text,uuid,text,integer) to service_role;

-- Explicit deny-by-default RLS: runtime uses service_role only.
-- No client policy is intentionally created for these private tables.

create index if not exists user_stats_updated_idx on public.user_stats(updated_at desc);
create index if not exists game_downloads_downloads_idx on public.game_downloads(downloads desc);
create index if not exists wallet_owned_game_idx on public.wallet_owned(game_id,owner_key);

-- Keep the used-ticket table small. Run periodically from a scheduled SQL job if desired.
create or replace function public.prune_used_tickets()
returns integer language sql security definer set search_path=public as $$
  with d as (delete from used_tickets where expires_at < now() returning 1)
  select count(*)::integer from d;
$$;
revoke all on function public.prune_used_tickets() from public, anon, authenticated;
grant execute on function public.prune_used_tickets() to service_role;
