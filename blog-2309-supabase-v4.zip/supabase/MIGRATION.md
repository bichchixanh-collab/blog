# Supabase migration

1. Mở Supabase SQL Editor và chạy `schema.sql`.
2. Đặt biến môi trường:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_KEY`
   - `SUPABASE_JWT_SECRET` (nếu project vẫn phát hành HS256; ES256 vẫn được hỗ trợ qua JWKS)
   - `LOCK_SECRET`
3. Từ thư mục project chạy `npm install` rồi `npm run migrate`.
4. Sau khi kiểm tra dữ liệu, `data/comments.json`, `data/economy.json`, `data/stats.json` chỉ còn là bản seed/backup; runtime không ghi GitHub nữa.

Production runtime dùng Supabase cho comments, wallet/economy, user stats và download counters. GitHub token không còn là dependency cho các dữ liệu mutable này.
