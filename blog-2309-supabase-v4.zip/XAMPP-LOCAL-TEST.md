# Test bằng XAMPP

1. Giải nén project vào `C:\xampp\htdocs\blog2309\`.
2. Bật Apache.
3. Mở `http://localhost/blog2309/`.
4. Game vật lý nằm trong `game/`, ví dụ `http://localhost/blog2309/game/haku-farm.html`.
5. `.htaccess` giữ file thật và tránh rewrite vòng về trang chủ.

Các `/api/*` là Vercel Serverless/Node và không chạy bằng Apache thuần. Muốn test API local cần chạy môi trường Node/Vercel tương ứng và cấu hình Supabase env.
