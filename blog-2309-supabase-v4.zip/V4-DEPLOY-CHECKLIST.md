# V4 deployment checklist

1. Run `supabase/schema.sql` in Supabase SQL Editor.
2. Set server-only env vars: `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `SUPABASE_JWT_SECRET` (if using HS256), `LOCK_SECRET`, and optionally Upstash/Turnstile.
3. Never expose `SUPABASE_SERVICE_KEY` or `LOCK_SECRET` to browser code.
4. Run `npm run migrate` once to import legacy JSON seed data.
5. Run `npm test` and `npm run audit`.
6. Deploy to Vercel.
7. For XAMPP, copy the project to `htdocs/blog2309/`; API endpoints require Node/Vercel, while static routing/UI can be tested locally.
8. Schedule `select public.prune_used_tickets();` daily in Supabase to prune consumed ticket rows.
