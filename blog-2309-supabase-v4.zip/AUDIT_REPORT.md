# Full audit — V4 Supabase production hardening

| Hạng mục | Trạng thái |
|---|---|
| Pet/Bingo | FIXED / REMOVED |
| user_stats bingo/pet_xp data-loss bug | REMOVED with feature |
| One-time ticket | FIXED: jti + Supabase atomic consume + identity binding |
| GitHub as mutable database | REMOVED from runtime |
| Download counter concurrency | FIXED with SQL atomic upsert |
| Economy double-spend | FIXED with PostgreSQL row lock/RPC |
| Economy guest identity | IMPROVED: signed HttpOnly guest cookie |
| Comment name spoofing for new comments | FIXED: uid/guest_key identity |
| Duplicate comments | Added 24h duplicate guard |
| SSR rating stale JSON | FIXED: Supabase query |
| Migration `err/error` | FIXED |
| Migration conflict keys | FIXED in current import script |
| Gate data `none` with stale fields | CLEANED |
| Automated syntax/validation/smoke tests | ADDED |
| XAMPP routing | PRESERVED/FIXED in V2 |
| CSP / inline JS | `unsafe-inline` remains intentionally because current UI still relies on inline scripts; no unsafe CSP relaxation beyond existing UI requirement |
| Upstash rate-limit | KEPT as recommended production dependency |
| Assets | NOT treated as a defect; intentionally omitted from lightweight ZIP |

## Production setup

Run `supabase/schema.sql`, then `npm run migrate` with Supabase environment variables. Runtime mutable data no longer needs a GitHub PAT.

| RPC permissions | FIXED: mutation RPCs revoked from anon/authenticated, service_role only |
| CSRF/origin checks | FIXED for state-changing browser endpoints |
| Guest cookie on XAMPP | FIXED: Secure only when HTTPS is actually used |
| Ticket subject theft | FIXED: ticket bound to authenticated UID or signed guest identity |
| Stats write abuse | FIXED: public stats endpoint is read-only; downloads increment only through gateway |
| Comment list scalability | IMPROVED: paginated top-level query + bounded reply query |
| Open redirect / forwarded host trust | HARDENED: SITE_URL preferred, otherwise sanitized request host |
