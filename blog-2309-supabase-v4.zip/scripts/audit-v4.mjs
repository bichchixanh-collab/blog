import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const banned=/\b(bingo|pet_xp|\bpet\b)\b/i;
const files=[];
function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){if(['node_modules','.git'].includes(e.name))continue;const p=path.join(d,e.name);if(e.isDirectory())walk(p);else files.push(p);}}
walk(root);
const hits=[];
for(const f of files){if(/\.(html|js|mjs|json|md|sql)$/.test(f)){const s=fs.readFileSync(f,'utf8');if(banned.test(s)&&!/(PATCH_NOTES|AUDIT_REPORT|RUNTIME-DATA|MIGRATION|audit-v4)/.test(f))hits.push(f);}}
const games=JSON.parse(fs.readFileSync(path.join(root,'data/games.json'),'utf8'));
const bad=games.filter(g=>g?.gate?.type && !['none','stats','login'].includes(g.gate.type));
if(bad.length)throw new Error('Unsupported gate types: '+bad.map(x=>x.id).join(', '));
if(hits.length)throw new Error('Pet/Bingo remnants: '+hits.join(', '));
if(!fs.existsSync(path.join(root,'supabase/schema.sql')))throw new Error('Missing Supabase schema');
console.log('V4 audit PASS: games=',games.length,' files=',files.length);
