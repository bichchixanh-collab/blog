// Import existing JSON data into Supabase. Safe to run repeatedly.
const fs=require('fs'),path=require('path');const {createClient}=require('@supabase/supabase-js');
const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_SERVICE_KEY;if(!url||!key){console.error('Missing SUPABASE_URL/SUPABASE_SERVICE_KEY');process.exit(1)}
const sb=createClient(url,key,{auth:{persistSession:false}});const root=process.cwd();
const read=(f,fb)=>{try{return JSON.parse(fs.readFileSync(path.join(root,f),'utf8'));}catch{return fb}};
async function upsert(table,rows,onConflict){if(!rows.length)return;for(let i=0;i<rows.length;i+=500){const chunk=rows.slice(i,i+500);const {error}=await sb.from(table).upsert(chunk,{onConflict});if(error)throw new Error(`${table}: ${error.message}`);}}
async function main(){
 const comments=read('data/comments.json',[]).map(c=>({id:String(c.id),game_id:String(c.game),name:String(c.name||'').slice(0,30),stars:Number(c.stars)||0,text:String(c.text||'').slice(0,500),status:['approved','pending','rejected'].includes(c.status)?c.status:'pending',created_at:c.created_at||new Date().toISOString(),parent_id:c.parentId||null,uid:c.uid||null,guest_key:c.guest_key||null,mod_reason:c.mod_reason||null}));
 await upsert('comments',comments,'id');
 const stats=read('data/stats.json',{});const downloads=Object.entries(stats).map(([game_id,v])=>({game_id,downloads:Number(v?.dl)||Number(v)||0}));await upsert('game_downloads',downloads,'game_id');
 const eco=read('data/economy.json',{});const wallets=[],owned=[],bonus=[];for(const [owner_key,v0] of Object.entries(eco)){const v=v0||{};wallets.push({owner_key,balance:Number(v.bal)||0,last_checkin:v.last||null,streak:Number(v.streak)||0});for(const game_id of Array.isArray(v.owned)?v.owned:[])owned.push({owner_key,game_id});for(const comment_id of Object.keys(v.bonus||{}))bonus.push({owner_key,comment_id,amount:5});}await upsert('wallets',wallets,'owner_key');await upsert('wallet_owned',owned,'owner_key,game_id');await upsert('wallet_bonus',bonus,'owner_key,comment_id');
 console.log(`Imported comments=${comments.length}, downloads=${downloads.length}, wallets=${wallets.length}, owned=${owned.length}, bonuses=${bonus.length}`);
}
main().catch(e=>{console.error(e.message);process.exitCode=1});
