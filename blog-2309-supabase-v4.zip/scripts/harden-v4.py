from pathlib import Path
import re, json, os
root=Path('/mnt/data/v4work')
# identity: localhost-compatible Secure cookie + robust parsing
p=root/'api/_identity.js'
s=p.read_text()
s=s.replace("const {bearerToken,verifySbTokenAsync}=require('./_sb');", "const {bearerToken,verifySbTokenAsync}=require('./_sb');\nfunction isHttps(req){return String(req.headers?.['x-forwarded-proto']||'').split(',')[0].trim()==='https'||String(req.headers?.host||'').endsWith('.vercel.app')||String(req.headers?.host||'').includes('.');}")
s=s.replace("res.setHeader('Set-Cookie',`j2me_guest=${id}.${sig}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax; Secure`);", "const secure=isHttps(req)?'; Secure':'';res.setHeader('Set-Cookie',`j2me_guest=${id}.${sig}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax${secure}`);")
p.write_text(s)
# _lib security helpers
p=root/'api/_lib.js'; s=p.read_text()
s=s.replace("function send(res, code, obj, maxAge = 30) {", "function requireSameOrigin(req) { return originStatus(req) === 'same'; }\nfunction send(res, code, obj, maxAge = 30) {")
s=s.replace("if (code === 200 && res.reqMethod === 'GET') res.setHeader('Access-Control-Allow-Origin', '*');", "if (code === 200 && String(res.reqMethod || '') === 'GET') res.setHeader('Access-Control-Allow-Origin', '*');")
s=s.replace("module.exports = { clientIp, hitRate, sameOrigin, originStatus, send, isValidId };", "module.exports = { clientIp, hitRate, sameOrigin, originStatus, requireSameOrigin, send, isValidId };")
p.write_text(s)
# _sb: strict JWT validation + no null row ambiguity + count approved server-side
p=root/'api/_sb.js'; s=p.read_text()
s=s.replace("if(body?.sub&&(!body.exp||body.exp>=Date.now()/1000-30))return {uid:String(body.sub),email:body.email||''};", "if(body?.sub&&(!body.exp||body.exp>=Date.now()/1000-30)&&(!body.nbf||body.nbf<=Date.now()/1000+30))return {uid:String(body.sub),email:body.email||''};")
s=s.replace("if(!body?.sub||Number(body.exp||0)<Date.now()/1000-30)return null;", "if(!body?.sub||Number(body.exp||0)<Date.now()/1000-30||Number(body.nbf||0)>Date.now()/1000+30)return null;")
s=s.replace("async function getUserStats(uid){try{const r=await sbRest('user_stats','?uid=eq.'+encodeURIComponent(uid)+'&select=minutes,likes,completed,updated_at');if(r.status===200)return cleanStats(r.json?.[0]);return null;}catch{return null;}}", "async function getUserStats(uid){try{const r=await sbRest('user_stats','?uid=eq.'+encodeURIComponent(uid)+'&select=minutes,likes,completed,updated_at');if(r.status!==200)return null;if(!Array.isArray(r.json)||!r.json[0])return {minutes:0,likes:[],completed:[],updated_at:null};return cleanStats(r.json[0]);}catch{return null;}}")
p.write_text(s)
# ticket binding + charge at consume
p=root/'api/_lock.js'; s=p.read_text()
s=s.replace("function mintTicket(id, res, gate, hard) {", "function subjectHash(subject) { return crypto.createHash('sha256').update(String(subject||''), 'utf8').digest('hex').slice(0, 32); }\nfunction mintTicket(id, res, gate, hard, subject='') {")
s=s.replace("gh: gateHash(gate), hard: hard ? 1 : 0", "gh: gateHash(gate), hard: hard ? 1 : 0, sub: subjectHash(subject)")
s=s.replace("if (!o || o.v !== 1 || !o.jti || !o.id || !o.res || typeof o.exp !== 'number') return null;", "if (!o || o.v !== 1 || !o.jti || !o.id || !o.res || !o.sub || typeof o.exp !== 'number') return null;")
s=s.replace("async function consumeTicket(jti, exp){", "async function consumeTicket(jti, exp){")
s=s.replace("module.exports = { consumeTicket, lockSecret", "module.exports = { subjectHash, consumeTicket, lockSecret")
# remove dead badge/xp server branches
s=re.sub(r"\n      if \(type === 'badge'\) \{.*?\n      \}\n      if \(type === 'xp'\) \{.*?\n      \}\n", "\n", s, flags=re.S)
p.write_text(s)
# ticket: bind identity, no charging until dl consume
p=root/'api/ticket.js'; s=p.read_text()
s=s.replace("const { mintTicket, checkProofExtended } = require('./_lock');", "const { mintTicket, checkProofExtended, subjectHash } = require('./_lock');")
s=s.replace("const { chargeForDownload, costOf } = require('./economy');\n", "const { costOf } = require('./economy');\n")
# after gate processing, resolve identity once
old="""    // Ví EXP: trừ giá tải của bài (tải lại game đã sở hữu thì miễn phí).
    {
      const cost = costOf(g);
      if (cost > 0) {
        const mePay = await verifySbTokenAsync(bearerToken(req));
        let cidPay = '';
        try {
          const raw = Buffer.from(String((req.query && req.query.proof) || '').replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
          const pj = JSON.parse(raw);
          if (pj && typeof pj.cid === 'string') cidPay = pj.cid.slice(0, 64);
        } catch (e) {}
        const pay = await chargeForDownload({ req, res, uid: mePay ? mePay.uid : null, cid: cidPay, gameId: id, cost });
        if (!pay.ok && pay.reason === 'low_exp') {
          send(res, 402, { error: 'low_exp', need: pay.need, bal: pay.bal });
          return;
        }
        if (!pay.ok) { send(res, 503, { error: 'economy unavailable' }); return; }
      }
    }
    const t = mintTicket(id, resName, gate || { type: 'none' }, hard);
"""
new="""    // Ticket gắn với đúng identity hiện tại. Việc trừ EXP được thực hiện tại /api/dl
    // sau khi ticket đã được consume atomically, tránh mất EXP khi người dùng bỏ dở.
    const meForTicket = await verifySbTokenAsync(bearerToken(req));
    const guestForTicket = meForTicket ? null : await identity(req, res);
    const subject = meForTicket ? 'u:'+meForTicket.uid : (guestForTicket?.key || '');
    if (!subject) { send(res, 503, { error: 'identity unavailable' }); return; }
    const t = mintTicket(id, resName, gate || { type: 'none' }, hard, subject);
"""
if old not in s: print('ticket old block not found')
s=s.replace(old,new)
p.write_text(s)
# dl: verify ticket subject and charge after consume; import subjectHash already
p=root/'api/dl.js'; s=p.read_text()
s=s.replace("const { verifyTicket, gateHash, mintTicket, resolveJarUrl, checkProofExtended, consumeTicket } = require('./_lock');", "const { verifyTicket, gateHash, mintTicket, resolveJarUrl, checkProofExtended, consumeTicket, subjectHash } = require('./_lock');")
old="""    // One-time ticket: Redis SET NX in production; memory fallback is for local/dev.
    const consumed = await consumeTicket(t.jti, t.exp);
    if (!consumed) { res.statusCode = 410; res.end('ticket already used or unavailable'); return; }
    await finishDl(req, res, g, t.res);
"""
new="""    // Ticket is one-time and bound to the same authenticated/guest identity that minted it.
    const { identity } = require('./_identity');
    const me = await require('./_sb').verifySbTokenAsync(require('./_sb').bearerToken(req));
    const ident = me ? { key:'u_'+me.uid } : await identity(req,res);
    const subject = me ? 'u:'+me.uid : ident?.key;
    if (!subject || t.sub !== subjectHash(subject)) { res.statusCode=403; res.end('ticket identity mismatch'); return; }
    const consumed = await consumeTicket(t.jti, t.exp);
    if (!consumed) { res.statusCode = 410; res.end('ticket already used or unavailable'); return; }
    const cost = require('./economy').costOf(g);
    if (cost > 0) {
      const pay = await require('./economy').chargeForDownload({req,res,uid:me?.uid||null,gameId:g.id,cost});
      if (!pay.ok) { res.statusCode=pay.reason==='low_exp'?402:503; res.setHeader('Content-Type','text/plain; charset=utf-8'); res.end(pay.reason==='low_exp'?`low_exp:${pay.need}:${pay.bal}`:'economy unavailable'); return; }
    }
    await finishDl(req, res, g, t.res);
"""
if old not in s: print('dl ticket block not found')
s=s.replace(old,new)
# don't mint unbound fallback ticket
s=s.replace("const t = mintTicket(g.id, resName, gate || { type: 'none' });", "const t = mintTicket(g.id, resName, gate || { type: 'none' }, 0, '');")
p.write_text(s)
# comments: CSRF same-origin, private mine no cache, crypto IDs, avoid identity cookie on read except mine
p=root/'api/comments.js'; s=p.read_text()
s=s.replace("const {check,ipOf}=require('./_rate');", "const {check,ipOf}=require('./_rate');\nconst {sameOrigin}=require('./_lib');\nconst crypto=require('crypto');")
s=s.replace("if(req.method!=='POST')return send(res,405,{error:'method not allowed'});", "if(req.method!=='POST')return send(res,405,{error:'method not allowed'});if(!sameOrigin(req))return send(res,403,{error:'origin denied'});")
s=s.replace("if(String(req.query?.mine||'')==='1'){const n=await countApproved(names(req.query?.names),id.uid,id.uid?null:id.key);return send(res,200,{mine:n,hard:!!id.uid},30);}", "if(String(req.query?.mine||'')==='1'){const n=await countApproved(names(req.query?.names),id.uid,id.uid?null:id.key);return send(res,200,{mine:n,hard:!!id.uid},0);}")
s=s.replace("const cid='c'+Date.now().toString(36)+cryptoRandom();", "const cid='c'+Date.now().toString(36)+crypto.randomBytes(8).toString('hex');")
s=s.replace("function cryptoRandom(){return Math.random().toString(36).slice(2,10);}\n", "")
p.write_text(s)
# economy CSRF
p=root/'api/economy.js'; s=p.read_text(); s=s.replace("const {check,ipOf}=require('./_rate');", "const {check,ipOf}=require('./_rate');\nconst {sameOrigin}=require('./_lib');")
s=s.replace("if(req.method==='POST'){", "if(req.method==='POST'){if(!sameOrigin(req))return send(res,403,{error:'origin denied'});")
p.write_text(s)
# stats POST csrf
p=root/'api/stats.js'; s=p.read_text(); s=s.replace("const {check,ipOf}=require('./_rate');", "const {check,ipOf}=require('./_rate');\nconst {sameOrigin}=require('./_lib');")
s=s.replace("if(req.method==='POST'){", "if(req.method==='POST'){if(!sameOrigin(req))return send(res,403,{error:'origin denied'});")
p.write_text(s)
# presence csrf (still can work with same-origin frontend)
p=root/'api/presence.js'; s=p.read_text(); s=s.replace("const { check, ipOf } = require('./_rate');", "const { check, ipOf } = require('./_rate');\nconst { sameOrigin } = require('./_lib');")
s=s.replace("if (req.method !== 'POST') { send(res, 405, { error: 'method not allowed' }); return; }", "if (req.method !== 'POST') { send(res, 405, { error: 'method not allowed' }); return; }\n    if (!sameOrigin(req)) { send(res, 403, { error: 'origin denied' }); return; }")
p.write_text(s)
# ustats POST csrf
p=root/'api/ustats.js'; s=p.read_text(); s=s.replace("const {check,ipOf}=require('./_rate');", "const {check,ipOf}=require('./_rate');\nconst {sameOrigin}=require('./_lib');")
s=s.replace("if(req.method==='POST'){", "if(req.method==='POST'){if(!sameOrigin(req))return send(res,403,{error:'origin denied'});")
p.write_text(s)
# SQL hardening: function execute grants + cleanup + constraints/indexes
p=root/'supabase/schema.sql'; s=p.read_text()
s += """

-- V4 hardening: RPCs are server-only. Supabase service role calls them through REST;
-- anon/authenticated clients must not be able to invoke wallet/stats mutations directly.
revoke all on function public.consume_ticket(text,timestamptz) from public, anon, authenticated;
revoke all on function public.user_stats_event(uuid,text,text) from public, anon, authenticated;
revoke all on function public.increment_download(text) from public, anon, authenticated;
revoke all on function public.wallet_checkin(text,uuid,date,integer) from public, anon, authenticated;
revoke all on function public.wallet_purchase(text,uuid,text,integer) from public, anon, authenticated;
revoke all on function public.wallet_credit_bonus(text,uuid,text,integer) from public, anon, authenticated;
grant execute on function public.consume_ticket(text,timestamptz) to service_role;
grant execute on function public.user_stats_event(uuid,text,text) to service_role;
grant execute on function public.increment_download(text) to service_role;
grant execute on function public.wallet_checkin(text,uuid,date,integer) to service_role;
grant execute on function public.wallet_purchase(text,uuid,text,integer) to service_role;
grant execute on function public.wallet_credit_bonus(text,uuid,text,integer) to service_role;

-- Explicit deny-by-default RLS: runtime uses service_role only.
-- No client policy is intentionally created for these private tables.

create index if not exists user_stats_updated_idx on public.user_stats(updated_at desc);
create index if not exists game_downloads_downloads_idx on public.game_downloads(downloads desc);
create index if not exists wallet_owned_game_idx on public.wallet_owned(game_id,owner_key);

-- Keep the used-ticket table small. Run periodically from a scheduled SQL job if desired.
create or replace function public.prune_used_tickets()
returns integer language sql security definer set search_path=public as $$
  with d as (delete from used_tickets where expires_at < now() returning 1)
  select count(*)::integer from d;
$$;
revoke all on function public.prune_used_tickets() from public, anon, authenticated;
grant execute on function public.prune_used_tickets() to service_role;
"""
p.write_text(s)
# package + env example
pkg=json.loads((root/'package.json').read_text()); pkg['scripts']['audit']='node scripts/audit-v4.mjs'; (root/'package.json').write_text(json.dumps(pkg,ensure_ascii=False,indent=2)+'\n')
(root/'.env.example').write_text('SUPABASE_URL=\nSUPABASE_SERVICE_KEY=\nSUPABASE_JWT_SECRET=\nLOCK_SECRET=replace-with-32+-random-chars\nUPSTASH_REDIS_REST_URL=\nUPSTASH_REDIS_REST_TOKEN=\nTURNSTILE_SECRET=\nSITE_URL=http://localhost/blog2309\nFILES_HOST=\n')
# remove obsolete Senpai gacha/badge snippets only; keep word Senpai branding
for p in [root/'game.html']+list((root/'game').glob('*.html')):
    s=p.read_text(errors='ignore')
    s=re.sub(r"\n?\s*if\(gt==='badge'\)\{try\{var s2=JSON\.parse\(localStorage\.getItem\('j2me_senpai'\)\|\|'null'\);if\(s2&&s2\.gacha&&s2\.gacha\.badges&&s2\.gacha\.badges\.length\)return null;\}catch\(e\)\{\}return\{label:cmtT\('g_gateBadge','Huy hiệu gacha hiếm'\),need:cmtT\('g_gateBadgeNeed','quay gacha ra huy hiệu đã'\)\};\}", "", s)
    p.write_text(s)
# remove obsolete goc-senpai feature page and any generated API file if exists
for rel in ['goc-senpai.html','api/senpai.js','api/pet.js','api/bingo.js','api/_bingo.js']:
    q=root/rel
    if q.exists(): q.unlink()
# remove stale data mutable JSON from runtime package? Keep as migration backup but clearly seed-only. Add README.
(root/'RUNTIME-DATA.md').write_text('''# Runtime data\n\nProduction runtime uses Supabase SQL for comments, user stats, wallets/economy, and download counters.\nThe JSON files in `data/` are migration/backup seeds only and are never written by runtime APIs.\n\nRun `supabase/schema.sql` once, then `npm run migrate`. Keep the service-role key server-side only.\n''')
# audit script
(root/'scripts/audit-v4.mjs').write_text('''import fs from 'node:fs';\nimport path from 'node:path';\nconst root=process.cwd();\nconst banned=/\\b(bingo|pet_xp|\\bpet\\b)\\b/i;\nconst files=[];\nfunction walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){if(['node_modules','.git'].includes(e.name))continue;const p=path.join(d,e.name);if(e.isDirectory())walk(p);else files.push(p);}}\nwalk(root);\nconst hits=[];\nfor(const f of files){if(/\\.(html|js|mjs|json|md|sql)$/.test(f)){const s=fs.readFileSync(f,'utf8');if(banned.test(s)&&!/(PATCH_NOTES|AUDIT_REPORT|RUNTIME-DATA|MIGRATION)/.test(f))hits.push(f);}}\nconst games=JSON.parse(fs.readFileSync(path.join(root,'data/games.json'),'utf8'));\nconst bad=games.filter(g=>g?.gate?.type && !['none','stats','login'].includes(g.gate.type));\nif(bad.length)throw new Error('Unsupported gate types: '+bad.map(x=>x.id).join(', '));\nif(hits.length)throw new Error('Pet/Bingo remnants: '+hits.join(', '));\nif(!fs.existsSync(path.join(root,'supabase/schema.sql')))throw new Error('Missing Supabase schema');\nconsole.log('V4 audit PASS: games=',games.length,' files=',files.length);\n''')
# Update vercel CSP remove unsafe-inline script only if no inline? We have inline, so keep. Add modern headers.
p=root/'vercel.json'; v=json.loads(p.read_text()); hdr=v['headers'][0]['headers'];
# Add COOP/CORP only if not present
keys={x['key'] for x in hdr}
if 'Cross-Origin-Opener-Policy' not in keys: hdr.append({'key':'Cross-Origin-Opener-Policy','value':'same-origin-allow-popups'})
if 'Cross-Origin-Resource-Policy' not in keys: hdr.append({'key':'Cross-Origin-Resource-Policy','value':'same-origin'})
if 'X-DNS-Prefetch-Control' not in keys: hdr.append({'key':'X-DNS-Prefetch-Control','value':'off'})
p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
# README deployment checklist
(root/'V4-DEPLOY-CHECKLIST.md').write_text('''# V4 deployment checklist\n\n1. Run `supabase/schema.sql` in Supabase SQL Editor.\n2. Set server-only env vars: `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `SUPABASE_JWT_SECRET` (if using HS256), `LOCK_SECRET`, and optionally Upstash/Turnstile.\n3. Never expose `SUPABASE_SERVICE_KEY` or `LOCK_SECRET` to browser code.\n4. Run `npm run migrate` once to import legacy JSON seed data.\n5. Run `npm test` and `npm run audit`.\n6. Deploy to Vercel.\n7. For XAMPP, copy the project to `htdocs/blog2309/`; API endpoints require Node/Vercel, while static routing/UI can be tested locally.\n8. Schedule `select public.prune_used_tickets();` daily in Supabase to prune consumed ticket rows.\n''')
