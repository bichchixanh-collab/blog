// Mutable download counters live in Supabase; no GitHub writes.
const { incrementDownload } = require('./_sb');
async function countDl(id){const n=await incrementDownload(id);if(n===null)throw new Error('download counter unavailable');return n;}
module.exports={countDl};
