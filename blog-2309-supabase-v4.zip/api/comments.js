const fs=require('fs'),path=require('path');
const {sbRest}=require('./_sb');
const {identity}=require('./_identity');
const {check,ipOf}=require('./_rate');
const {sameOrigin}=require('./_lib');
const crypto=require('crypto');
const {checkComment,isAutoApprove}=require('./_moderate');
const {creditCommentBonus}=require('./economy');
function send(res,c,o,max=30){res.statusCode=c;res.setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Cache-Control',`public,max-age=${max},must-revalidate`);res.end(JSON.stringify(o));}
function gameExists(id){try{return JSON.parse(fs.readFileSync(path.join(process.cwd(),'data','games.json'),'utf8')).some(g=>g?.id===id);}catch{return false;}}
function names(s){return String(s||'').split(',').map(x=>x.trim().slice(0,30)).filter(Boolean).slice(0,5);}
function pub(c){return {id:c.id,name:String(c.name||'').slice(0,30),stars:c.parent_id?0:Math.min(5,Math.max(1,Number(c.stars)||1)),text:String(c.text||'').slice(0,500),created_at:c.created_at||'',replies:[]};}
async function listGame(game,page=1,limit=5){
  const lim=Math.min(20,Math.max(1,parseInt(limit,10)||5));
  const pg=Math.max(1,parseInt(page,10)||1);
  const offset=(pg-1)*lim;
  const top=await sbRest('comments',`?game_id=eq.${encodeURIComponent(game)}&status=eq.approved&parent_id=is.null&select=id,game_id,name,stars,text,created_at,parent_id&order=created_at.desc&offset=${offset}&limit=${lim}`,{headers:{Prefer:'count=exact'}});
  if(top.status!==200)throw new Error('comments unavailable');
  const totalRaw=top.headers?.get?.('content-range')||'';
  const totalMatch=String(totalRaw).match(/\/([0-9]+)$/);
  const total=totalMatch?Number(totalMatch[1]):(top.json||[]).length;
  const tops=Array.isArray(top.json)?top.json:[];
  const pages=Math.max(1,Math.ceil(total/lim));
  const pg2=Math.min(pg,pages);
  const ids=tops.map(c=>c.id).filter(Boolean);
  let replies=[];
  if(ids.length){
    const inList='('+ids.map(x=>'"'+String(x).replace(/"/g,'\\"')+'"').join(',')+')';
    const rr=await sbRest('comments',`?parent_id=in.${encodeURIComponent(inList)}&game_id=eq.${encodeURIComponent(game)}&status=eq.approved&select=id,game_id,name,stars,text,created_at,parent_id&order=created_at.asc&limit=200`);
    if(rr.status!==200)throw new Error('comments unavailable'); replies=rr.json||[];
  }
  const map={};for(const c of replies)(map[c.parent_id]??=[]).push(c);
  const out=tops.map(c=>{const o=pub(c);o.replies=(map[c.id]||[]).slice(0,20).map(pub);return o;});
  const sr=await sbRest('comments',`?game_id=eq.${encodeURIComponent(game)}&status=eq.approved&parent_id=is.null&select=stars&limit=500`);
  const stars=sr.status===200?(sr.json||[]):[];const avg=stars.length?Math.round(stars.reduce((a,c)=>a+(Number(c.stars)||0),0)/stars.length*10)/10:0;
  return {game,avg,total,page:Math.min(pg2,pages),limit:lim,pages,comments:out};
}
async function countApproved(namesList,uid,guestKey){let q='?status=eq.approved&select=id,uid,guest_key,name';if(uid)q+='&uid=eq.'+encodeURIComponent(uid);else if(guestKey)q+='&guest_key=eq.'+encodeURIComponent(guestKey);else if(namesList?.length){q+='&name=in.('+namesList.map(x=>`"${x.replace(/"/g,'\\"')}"`).join(',')+')';}else return 0;const r=await sbRest('comments',q);return r.status===200?(r.json||[]).length:0;}
function body(req){return req.body&&typeof req.body==='object'?req.body:{};}
async function turnstile(token,ip){if(!process.env.TURNSTILE_SECRET)return true;try{const r=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({secret:process.env.TURNSTILE_SECRET,response:String(token||''),remoteip:ip})});const j=await r.json();return !!j?.success;}catch{return false;}}
module.exports=async(req,res)=>{try{const post=req.method==='POST';if(!(await check({ip:ipOf(req),route:post?'cmt-post':'cmt-get',limit:post?10:100,windowS:post?600:60})))return send(res,429,{error:'slow down'});if(req.method==='GET'){const id=await identity(req,res);if(String(req.query?.mine||'')==='1'){const n=await countApproved(names(req.query?.names),id.uid,id.uid?null:id.key);return send(res,200,{mine:n,hard:!!id.uid},0);}const game=String(req.query?.game||'').slice(0,120);if(!game)return send(res,400,{error:'missing game'});return send(res,200,await listGame(game,req.query?.page,req.query?.limit),15);}if(req.method!=='POST')return send(res,405,{error:'method not allowed'});if(!sameOrigin(req))return send(res,403,{error:'origin denied'});if((String(req.body?.website||'')).trim())return send(res,200,{ok:true});if(!(await turnstile(body(req).turnstile,ipOf(req))))return send(res,403,{error:'captcha failed'});const p=body(req),game=String(p.game||'').slice(0,120),name=String(p.name||'').trim().slice(0,30),text=String(p.text||'').trim().slice(0,500),replyTo=String(p.replyTo||'').slice(0,80),stars=Math.min(5,Math.max(1,parseInt(p.stars,10)||0));if(!gameExists(game))return send(res,400,{error:'game invalid'});if(name.length<2||text.length<2)return send(res,400,{error:'invalid comment'});const id=await identity(req,res);
const dupQ=id.uid?`?game_id=eq.${encodeURIComponent(game)}&uid=eq.${encodeURIComponent(id.uid)}&status=neq.rejected&text=eq.${encodeURIComponent(text)}&created_at=gte.${encodeURIComponent(new Date(Date.now()-86400000).toISOString())}&select=id&limit=1`:id.key?`?game_id=eq.${encodeURIComponent(game)}&guest_key=eq.${encodeURIComponent(id.key)}&status=neq.rejected&text=eq.${encodeURIComponent(text)}&created_at=gte.${encodeURIComponent(new Date(Date.now()-86400000).toISOString())}&select=id&limit=1`:'';
if(dupQ){const dq=await sbRest('comments',dupQ);if(dq.status===200&&dq.json?.length)return send(res,409,{error:'duplicate comment'});}
let parent=null;if(replyTo){const q=await sbRest('comments','?id=eq.'+encodeURIComponent(replyTo)+'&game_id=eq.'+encodeURIComponent(game)+'&status=eq.approved&select=id,parent_id');if(q.status!==200||!q.json?.[0]||q.json[0].parent_id)return send(res,400,{error:'reply target invalid'});parent=q.json[0].id;}const auto=isAutoApprove();const chk=auto?await checkComment({text,name}):{ok:false,reason:'auto disabled'};const status=auto&&chk.ok?'approved':'pending';const cid='c'+Date.now().toString(36)+crypto.randomBytes(8).toString('hex');const row={id:cid,game_id:game,name,stars:parent?0:stars,text,status,created_at:new Date().toISOString(),parent_id:parent||null,uid:id.uid,guest_key:id.uid?null:id.key,mod_reason:status==='pending'&&!chk.ok?String(chk.reason||'').slice(0,120):null};const ins=await sbRest('comments',{method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify(row)});if(ins.status!==201)return send(res,503,{error:'comments unavailable'});let xpBonus=false;if(status==='approved'&&id.uid){try{xpBonus=!!(await creditCommentBonus({uid:id.uid,commentId:cid,amount:5})).credited;}catch{}}return send(res,200,{ok:true,status,xpBonus});}catch(e){try{console.error('comments',e)}catch{}return send(res,500,{error:'error'});}};
module.exports.countApproved=countApproved;
