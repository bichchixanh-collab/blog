# Runtime data

Production runtime uses Supabase SQL for comments, user stats, wallets/economy, and download counters.
The JSON files in `data/` are migration/backup seeds only and are never written by runtime APIs.

Run `supabase/schema.sql` once, then `npm run migrate`. Keep the service-role key server-side only.
