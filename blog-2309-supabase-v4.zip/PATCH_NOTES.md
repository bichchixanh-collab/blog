# V4 production hardening

## Removed
- Pet/Bingo runtime features and gate types.
- Runtime writes to GitHub JSON.

## Supabase SQL
- Comments, user stats, wallet/economy, download counters and used tickets use Supabase/PostgreSQL.
- Atomic wallet operations use row locking inside security-definer RPCs.
- Download counter uses atomic upsert.
- Ticket consumption uses an atomic one-time RPC.
- Mutation RPCs are executable only by `service_role`; `anon`/`authenticated` are revoked.
- Added indexes and ticket pruning function.

## Download security
- HMAC ticket is bound to the authenticated UID or signed guest identity.
- Ticket is consumed once before redirect.
- Paid download is charged only after successful ticket consumption, preventing charges for abandoned ticket pages.
- Current gate hash is checked again at consume time.
- File host is strict allowlist; no untrusted host fallback redirect.
- `SITE_URL` is preferred for redirects to avoid forwarded-host/open-redirect ambiguity.

## API/security
- State-changing browser endpoints enforce same-origin requests.
- Public `/api/stats` is read-only; counters can only be incremented by the download gateway.
- Guest identity uses signed HttpOnly cookie; `Secure` is enabled only over HTTPS so XAMPP HTTP works.
- JWT `nbf` is checked in addition to signature/expiry.
- Private `mine=1` comment responses are not publicly cacheable.
- Comment IDs use cryptographic randomness.

## Performance
- Comment list now paginates top-level comments in SQL and fetches only replies for the current page.
- Runtime mutable data is no longer read/written through GitHub.

## Validation
- 28 JS/MJS files syntax-clean.
- `games.json` validation passes.
- Smoke tests pass, including ticket identity binding.
- V4 audit passes with 15 games and no Pet/Bingo runtime remnants.

## Assets
The lightweight ZIP intentionally does not include the user's heavy `assets/` directory. Existing asset paths and UI structure are preserved.
