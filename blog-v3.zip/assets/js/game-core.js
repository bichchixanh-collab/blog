// Stats local cho khóa tải: phút online + lượt thích + phá đảo + tên bình luận
function stGet(k,d){try{var v=localStorage.getItem(k);return v==null?d:JSON.parse(v);}catch(e){return d;}}
function stSet(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
function stMinutes(){return Math.floor((+stGet('j2me_online_ms',0))/60000);}
// Số phút đã ký bởi server (presence chain) — đây mới là số được chấp nhận khi xin vé.
// Chưa có chain thì rớt về số local để hiển thị; server siết: thiếu chain hợp lệ là rớt vé.
function stPresence(){try{var p=JSON.parse(localStorage.getItem('j2me_presence')||'null');if(p&&typeof p.tok==='string'&&p.tok)return {tok:p.tok,n:Math.max(0,parseInt(p.n||0,10)||0)};}catch(e){}return null;}
function stVerifiedMin(){var pr=stPresence();return pr?pr.n:stMinutes();}
function stLikes(){var a=stGet('j2me_favs',[]);return Array.isArray(a)?a.length:0;}
function stDone(){var a=stGet('j2me_done',[]);return Array.isArray(a)?a.length:0;}
function stNames(){var a=stGet('j2me_names',[]);return Array.isArray(a)?a.filter(Boolean).slice(0,5):[];}
function stSaveName(n){n=String(n||'').trim().slice(0,30);if(n.length<2)return;var a=stNames(),l=n.toLowerCase(),has=false;for(var i=0;i<a.length;i++)if(String(a[i]).toLowerCase()===l)has=true;if(!has){a.push(n);stSet('j2me_names',a.slice(-5));}}
function stApiRoot(){try{var p=location.pathname||'/';var gi=p.indexOf('/game/');return gi>=0?p.slice(0,gi):'';}catch(e){return '';}}
function stToken(){try{var s=JSON.parse(localStorage.getItem('sb_session')||'null');return (s&&s.access_token)||'';}catch(e){return '';}}
// Token tươi: tự refresh khi sắp hết hạn (SBAuth), rớt về token cũ nếu không refresh được.
// Form bình luận/ví/vé DÙNG HÀM NÀY thay vì stToken() để server luôn nhận đúng tài khoản.
async function stFreshToken(){try{if(window.SBAuth&&SBAuth.session){var s=await SBAuth.session();if(s&&s.access_token)return s.access_token;}}catch(e){}try{return stToken();}catch(e){return '';}}
function stUid(){try{var t=stToken();if(!t)return '';var p=(t.split('.')[1]||'').replace(/-/g,'+').replace(/_/g,'/');while(p.length%4)p+='=';var j=JSON.parse(atob(p));return j.sub||'';}catch(e){return '';}}
function stLogged(){return !!stToken();}
function stAuthHeaders(){var t=stToken();return t?{'Authorization':'Bearer '+t}:{};}
function stEvent(t,id){try{var tk=stToken();if(!tk)return;fetch(stApiRoot()+'/api/ustats',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tk},body:JSON.stringify({t:t,id:String(id||'').slice(0,120)}),keepalive:true}).catch(function(){});}catch(e){}}
var _stApprCache={at:0,n:-1};
function stCid(){try{var c=localStorage.getItem('j2me_cid');if(typeof c==='string'&&/^[0-9a-f]{24}$/.test(c))return c;c='';var ch='0123456789abcdef';for(var i=0;i<24;i++)c+=ch[Math.floor(Math.random()*16)];try{localStorage.setItem('j2me_cid',c);}catch(e){}return c;}catch(e){return '';}}
function stApprovedCount(cb){var now=Date.now();if(_stApprCache.n>=0&&now-_stApprCache.at<60000){cb(_stApprCache.n);return;}var tk='';try{tk=stToken();}catch(e){}var names=stNames();if(!tk&&!names.length){cb(0);return;}var url=stApiRoot()+'/api/comments?mine=1'+(names.length?'&names='+encodeURIComponent(names.join(',')):'');var hh=tk?{'Authorization':'Bearer '+tk}:{};fetch(url,{headers:hh,cache:'no-store'}).then(function(r){return r.json();}).then(function(j){var n=+(j&&j.mine)||0;_stApprCache={at:now,n:n};cb(n);}).catch(function(){cb(_stApprCache.n>=0?_stApprCache.n:0);});}

(function(){try{setInterval(function(){try{if(document.hidden)return;var ms=+localStorage.getItem('j2me_online_ms')||0;localStorage.setItem('j2me_online_ms',String(ms+60000));}catch(e){}try{var tk=stToken();if(tk)fetch(stApiRoot()+'/api/ustats',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tk},body:JSON.stringify({t:'heartbeat'}),keepalive:true}).catch(function(){});}catch(e){}try{var pr=null;try{pr=JSON.parse(localStorage.getItem('j2me_presence')||'null');}catch(e){}fetch(stApiRoot()+'/api/presence',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tok:(pr&&pr.tok)||'',cid:stCid()}),keepalive:true}).then(function(r){return r.json();}).then(function(j){if(j&&j.tok)try{localStorage.setItem('j2me_presence',JSON.stringify({tok:j.tok,n:j.n||0}));}catch(e){}}).catch(function(){});}catch(e){}},60000);}catch(e){}})();

function tick(){const el=document.getElementById('clock');if(el)el.textContent=new Date().toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'})}
tick();setInterval(tick,30000);
document.addEventListener('error',function(e){var t=e.target;if(!t||t.tagName!=='IMG')return;if(t.id==='wapBannerImg'){if(!t.dataset.fb1){t.dataset.fb1='1';t.src=apiRoot()+'/assets/banners/banner1.webp';}else if(!t.dataset.fb){t.dataset.fb='1';t.src=apiRoot()+'/assets/anime-girl.webp';}return;}if(!t.dataset.fb){t.dataset.fb='1';t.src=apiRoot()+'/assets/anime-girl.webp';}},true);
(function(){
  // Random toàn bộ ảnh trong assets/banners (.png/.jpg/...): quét qua API, không fix cứng tên/số lượng.
  // Thêm/xóa ảnh chỉ cần copy file vào assets/banners.
  // API chỉ trả TÊN FILE; JS tự dựng URL theo đúng subfolder (http://localhost/blog hay domain root đều đúng).
  var FALLBACK_NAMES=['banner1.webp','banner2.webp','banner3.webp','banner4.webp','banner5.webp','banner6.webp'];
  function appRoot(){
    try{
      var p=location.pathname||'/';
      var gi=p.indexOf('/game/');
      if(gi>=0) return p.slice(0,gi).replace(/\/$/,'');
      if(p.length>1&&p.charAt(p.length-1)==='/') return p.slice(0,-1);
      var i=p.lastIndexOf('/');
      return i<=0?'':p.slice(0,i);
    }catch(e){return '';}
  }
  function baseFromApiUrl(u,root){
    try{return new URL('../assets/banners/',u).toString();}catch(e){}
    return root+'/assets/banners/';
  }
  function toNames(a){
    var out=[];
    (a||[]).forEach(function(x){
      if(typeof x!=='string')return;
      x=x.trim(); if(!x)return;
      x=x.split('?')[0].split('#')[0];
      var b=x.substring(x.lastIndexOf('/')+1);
      if(!/\.(png|jpe?g|gif|webp)$/i.test(b))return;
      out.push(b);
    });
    return out;
  }
  function toUrls(names,base){
    if(base.charAt(base.length-1)!=='/')base+='/';
    return names.map(function(n){return base+encodeURIComponent(n);});
  }
  var ROOT=appRoot();
  var FALLBACK_URLS=toUrls(FALLBACK_NAMES,ROOT+'/assets/banners/');
  window.__BANNER_FALLBACK=FALLBACK_URLS;
  window.__BANNER_CACHE=null;
  window.getBannerList=async function(){
    if(window.__BANNER_CACHE&&window.__BANNER_CACHE.length) return window.__BANNER_CACHE;
    // Chỉ dùng endpoint tuyệt đối theo ROOT. KHÔNG dùng relative 'api/...'/'data/...'
    // vì từ trang /game/*.html chúng resolve thành /game/api/... gây 404/403 rác console.
    var urls=[ROOT+'/api/banners',ROOT+'/data/banners.json',ROOT+'/api/banners.php'];
    for(var i=0;i<urls.length;i++){
      var u=urls[i];
      try{
        var r=await fetch(u,{cache:'no-store'});
        if(!r.ok) continue;
        var j=await r.json();
        var names=toNames(Array.isArray(j)?j:(j&&Array.isArray(j.files)?j.files:null));
        if(names.length){
          var respUrl=(r.url&&r.url.indexOf('http')===0)?r.url:new URL(u,location.href).toString();
          var list=toUrls(names,baseFromApiUrl(respUrl,ROOT));
          window.__BANNER_CACHE=list;return list;
        }
      }catch(e){}
    }
    window.__BANNER_CACHE=FALLBACK_URLS;
    return FALLBACK_URLS;
  };
  // Random nhưng KHÔNG trùng ảnh vừa hiện lần trước (lưu tên file vào localStorage).
  function bannerName(u){try{return decodeURIComponent(String(u||'').split('?')[0].split('#')[0].split('/').pop());}catch(e){return '';}}
  function getBannerQueue(){try{var q=JSON.parse(localStorage.getItem('j2me_banner_queue')||'[]');return Array.isArray(q)?q:[];}catch(e){return [];}}
  function saveBannerQueue(q){try{localStorage.setItem('j2me_banner_queue',JSON.stringify(q.slice(0,500)));}catch(e){}}
  function shuffledArr(a){var r=a.slice();for(var i=r.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=r[i];r[i]=r[j];r[j]=t;}return r;}
  window.pickRandomBanner=function(list,nosave){var a=(list&&list.length)?list:(window.__BANNER_CACHE&&window.__BANNER_CACHE.length?window.__BANNER_CACHE:window.__BANNER_FALLBACK);if(!a||!a.length)return '';if(a.length<2)return a[0];var names=a.map(bannerName);var q=getBannerQueue().filter(function(n){return names.indexOf(n)>=0;});if(!q.length){q=shuffledArr(names);try{var last=localStorage.getItem('j2me_last_banner')||'';if(last&&q[0]===last&&q.length>1){q.push(q.shift());}}catch(e){}}var pickName=q[0];var pick=a[names.indexOf(pickName)]||a[0];if(nosave)return pick;q.shift();saveBannerQueue(q);try{localStorage.setItem('j2me_last_banner',pickName);}catch(e){}return pick;};
  // Link chân trang theo đúng subfolder (trang game có thể ở /game/ sâu 1 cấp) - fix cả link và script
  function fixRoots(){try{var r=ROOT;document.querySelectorAll('a[data-root-link]').forEach(function(a){a.href=r+'/'+a.getAttribute('data-root-link');});document.querySelectorAll('img[data-root-src]').forEach(function(im){im.src=r+'/'+im.getAttribute('data-root-src');});document.querySelectorAll('link[data-root-href]').forEach(function(l){l.href=r+'/'+l.getAttribute('data-root-href');});document.querySelectorAll('script[data-root-href]').forEach(function(s){if(s.src!==r+'/'+s.getAttribute('data-root-href'))s.src=r+'/'+s.getAttribute('data-root-href');});}catch(e){}}
  fixRoots(); try{document.addEventListener('DOMContentLoaded',fixRoots);}catch(e){}
  var img=document.getElementById('wapBannerImg');
  if(img){
    try{img.src=window.pickRandomBanner(FALLBACK_URLS,true);}catch(e){}
    window.getBannerList().then(function(list){try{img.src=window.pickRandomBanner(list);}catch(e){}}).catch(function(){});
  }
})();
// Lightbox xem ảnh vuốt
let CURRENT_SHOTS=[];
let LB_INDEX=0;
const lb=document.getElementById('lightbox');
const lbTrack=document.getElementById('lbTrack');
const lbCounter=document.getElementById('lbCounter');
function renderLightbox(){
  const n=CURRENT_SHOTS.length;
  lbTrack.style.width=`${n*100}vw`;
  lbTrack.innerHTML=CURRENT_SHOTS.map(s=>`<img src="${s}" alt="Screenshot" style="width:100vw">`).join('');
  updateLightboxPos(false);
}
function updateLightboxPos(animate=true){
  lbTrack.style.transition=animate?'transform .25s ease':'none';
  lbTrack.style.transform=`translateX(${-LB_INDEX*100}vw)`;
  lbCounter.textContent=`${LB_INDEX+1} / ${CURRENT_SHOTS.length}`;
}
function openLightbox(idx){
  if(!CURRENT_SHOTS.length) return;
  try{var fp=document.getElementById('fogPct'); if(fp&&fp.style.display!=='none') return;}catch(e){}
  LB_INDEX=idx;
  renderLightbox();
  lb.classList.remove('hidden');
  document.body.style.overflow='hidden';
}
function closeLightbox(){
  lb.classList.add('hidden');
  document.body.style.overflow='';
}
function lbGoto(idx){
  if(idx<0) idx=0;
  if(idx>CURRENT_SHOTS.length-1) idx=CURRENT_SHOTS.length-1;
  LB_INDEX=idx;
  updateLightboxPos(true);
}
document.getElementById('lbClose')?.addEventListener('click',closeLightbox);
document.getElementById('lbPrev')?.addEventListener('click',()=>lbGoto(LB_INDEX-1));
document.getElementById('lbNext')?.addEventListener('click',()=>lbGoto(LB_INDEX+1));
lb?.addEventListener('click',e=>{ if(e.target===lb) closeLightbox(); });
document.addEventListener('keydown',e=>{
  if(lb.classList.contains('hidden')) return;
  if(e.key==='Escape') closeLightbox();
  if(e.key==='ArrowLeft') lbGoto(LB_INDEX-1);
  if(e.key==='ArrowRight') lbGoto(LB_INDEX+1);
});
// Vuốt (touch swipe)
let touchStartX=0, touchDeltaX=0, touching=false;
lbTrack?.addEventListener('touchstart',e=>{
  touching=true; touchStartX=e.touches[0].clientX; touchDeltaX=0;
  lbTrack.style.transition='none';
},{passive:true});
lbTrack?.addEventListener('touchmove',e=>{
  if(!touching) return;
  touchDeltaX=e.touches[0].clientX-touchStartX;
  lbTrack.style.transform=`translateX(calc(${-LB_INDEX*100}vw + ${touchDeltaX}px))`;
},{passive:true});
lbTrack?.addEventListener('touchend',()=>{
  if(!touching) return;
  touching=false;
  const threshold=(lb.clientWidth||1)*0.18;
  if(touchDeltaX>threshold) lbGoto(LB_INDEX-1);
  else if(touchDeltaX<-threshold) lbGoto(LB_INDEX+1);
  else updateLightboxPos(true);
});

// Dynamic - giữ y giao diện vải
let GAMES_MAP=null;
async function loadMap(force){ if(GAMES_MAP&&!force) return GAMES_MAP; const r=await fetch(apiRoot()+'/data/games.json',{headers:{Accept:'application/json'}}); const arr=await r.json(); GAMES_MAP={}; arr.forEach(g=>GAMES_MAP[g.id]=g); return GAMES_MAP; }
function getId(){
  const p=new URLSearchParams(location.search);
  let id=p.get('id');
  if(id) return id.replace(/\.html$/,'');
  const m=location.pathname.match(/\/game\/([^\/]+)\.html$/);
  if(m) return decodeURIComponent(m[1]);
  const m2=location.pathname.match(/\/game\/([^\/]+)$/);
  if(m2) return decodeURIComponent(m2[1]);
  return 'kiem-linh-chu-tien-chi-chien';
}
// Chống XSS: escape mọi dữ liệu game trước khi chèn vào HTML; linkify biến URL trong mô tả thành link bấm được
function escHtml(s){return String(s==null?'':s).replace(/[&<>"']/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];});}
function linkify(s){return escHtml(s).replace(/\*\*([^*<>]+)\*\*/g,'<b>$1</b>').replace(/(https?:\/\/[^\s<>"']+)/g,'<a href="$1" target="_blank" rel="noopener">$1</a>');}
// Thẻ [credit]...[/credit] trong mô tả: hộp chủ quyền nổi bật, link tuyệt đối + nút chép
// để khi bài bị copy đi nơi khác vẫn mang theo nguồn. Không có thẻ thì render như cũ.
// Dòng © NGUỒN đứng ngay trước [credit] được gộp làm tiêu đề hộp (không render 2 lần).
function creditHeaderHtml(h){
  var t=escHtml(String(h||'').trim());
  if(!t) t=cmtT('g_creditSrc','© NGUỒN: J2ME.VERCEL.APP');
  t=t.replace(/(https?:\/\/[^\s<>"']+)/g,'<a href="$1" target="_blank" rel="noopener" style="color:#7a5a00">$1</a>');
  if(t.indexOf('J2ME.VERCEL.APP')<0) t+=' — <a href="https://J2ME.VERCEL.APP" target="_blank" rel="noopener" style="color:#7a5a00">J2ME.VERCEL.APP</a>';
  return t;
}
function renderCreditBox(inner,headerHtml){
  var body=String(inner).replace(/(https?:\/\/[^\s<>"']+)/g,'<a href="$1" target="_blank" rel="noopener">$1</a>');
  return '<div class="credit-box" style="margin:10px 0;padding:10px 12px;background:linear-gradient(180deg,#fffbe6,#fff3c4);border:2px dashed #e6a800;border-radius:10px;box-shadow:0 2px 8px rgba(230,168,0,.25)">'
  +'<div style="font-weight:800;color:#7a5a00;font-size:12px;margin-bottom:6px">'+headerHtml+'</div>'
  +'<div style="font-size:12.5px;color:#1a3a5c;white-space:pre-line">'+body+'</div>'
  +'<div style="margin-top:8px"><button type="button" data-credit-copy="1" style="background:#7a5a00;color:#fff;border:none;border-radius:6px;padding:5px 12px;font-size:11px;font-weight:700;cursor:pointer">'+cmtT('g_creditCopy','📋 Chép credit')+'</button></div></div>';
}
document.addEventListener('click',function(e){var b=e.target&&e.target.closest?e.target.closest('[data-credit-copy]'):null;if(!b)return;try{navigator.clipboard.writeText(b.parentNode.parentNode.innerText).then(function(){b.textContent=cmtT('g_creditCopied','✓ Đã chép!');}).catch(function(){});}catch(err){}});
document.addEventListener('click',function(e){var b=e.target&&e.target.closest?e.target.closest('[data-relock]'):null;if(!b)return;try{localStorage.removeItem('j2me_presence');}catch(err){}location.reload();});
document.addEventListener('click',function(e){
  var b=e.target&&e.target.closest?e.target.closest('[data-eco-comment]'):null;if(!b)return;
  try{var mc=document.getElementById('modalCancel');if(mc)mc.click();}catch(err){}
  setTimeout(function(){
    try{
      var box=document.getElementById('cmtBox'); if(box){box.style.display='block';box.scrollIntoView({behavior:'smooth',block:'start'});}
      var tx=document.getElementById('cmtText'); if(tx)tx.focus({preventScroll:true});
    }catch(err2){}
  },150);
});
function renderDesc(s){
  var parts=[],heads=[];
  var raw=String(s||'');
  raw=raw.replace(/([^\n]*©[^\n]*)\r?\n\s*\[credit\]/gi,function(m,h){heads.push(h);return '[credit]@@HDR'+(heads.length-1)+'@@\n';});
  var t=escHtml(raw);
  t=t.replace(/\[credit\]([\s\S]*?)\[\/credit\]/gi,function(m,inner){parts.push(inner);return 'CREDITBOX'+(parts.length-1)+'X';});
  t=t.replace(/\*\*([^*<>]+)\*\*/g,'<b>$1</b>').replace(/(https?:\/\/[^\s<>"']+)/g,'<a href="$1" target="_blank" rel="noopener">$1</a>');
  for(var i=0;i<parts.length;i++){
    (function(idx){
      var inner=parts[idx],h='';
      inner=inner.replace(/@@HDR(\d+)@@/,function(mm,k){h=creditHeaderHtml(heads[+k]||'');return '';});
      t=t.split('CREDITBOX'+idx+'X').join(renderCreditBox(inner,h||creditHeaderHtml('')));
    })(i);
  }
  return t;
}
function apiRoot(){try{const p=location.pathname||'/';const gi=p.indexOf('/game/');return gi>=0?p.slice(0,gi):'';}catch(e){return '';}}
function isPreviewMode(){try{return new URLSearchParams(location.search).get('preview')==='1';}catch(e){return false;}}
// Đếm lượt bấm tải thật: mỗi máy 1 lượt/ngày/game, gửi nền không chặn tải
function countDownload(gameId){
  if(!gameId||isPreviewMode())return;
  try{
    const day=new Date().toISOString().slice(0,10);
    const k='dl_'+gameId+'_'+day;
    if(localStorage.getItem(k))return;
    localStorage.setItem(k,'1');
    xpBump('download',gameId);
    // Không POST /api/stats ở đây nữa — gateway /api/dl đã đếm server-side,
    // tránh đếm trùng 2 lần cho 1 lượt tải.
  }catch(e){}
}
// Yêu thích (localStorage, tối đa 200 game)
function favGet(){try{const a=JSON.parse(localStorage.getItem('j2me_favs')||'[]');return Array.isArray(a)?a:[];}catch(e){return [];}}
function favHas(id){try{return favGet().indexOf(id)>=0;}catch(e){return false;}}
function favToggle(id){try{let a=favGet();a=a.indexOf(id)>=0?a.filter(function(x){return x!==id;}):a.concat([id]);localStorage.setItem('j2me_favs',JSON.stringify(a.slice(0,200)));var _fr=a.indexOf(id)>=0;try{__bm('fav');}catch(e){}try{stEvent(_fr?'like':'unlike',id);}catch(e){}return _fr;}catch(e){return false;}}
function copyPageUrl(url,btn){function done(t){if(btn){btn.textContent=t;setTimeout(function(){btn.textContent=cmtT('g_copy','Copy link');},1500);}}if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(url).then(function(){done(cmtT('g_copied','Đã copy!'));}).catch(function(){done(cmtT('g_copyerr','Copy lỗi'));});}else{try{const ta=document.createElement('textarea');ta.value=url;document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);done(cmtT('g_copied','Đã copy!'));}catch(e){done(cmtT('g_copyerr','Copy lỗi'));}}}
// XP + nhiệm vụ hằng ngày (xem 3 game / thích 1 / bình luận 1, mỗi cái +10)
function xpAdd(n){try{const o=JSON.parse(localStorage.getItem('j2me_xp')||'{"xp":0}')||{xp:0};o.xp=(o.xp||0)+n;localStorage.setItem('j2me_xp',JSON.stringify(o));}catch(e){}}
function xpBump(kind,gameId){
  try{
    if(kind==='visit'&&gameId){let a=[];try{a=JSON.parse(localStorage.getItem('j2me_seen')||'[]');}catch(e){}if(a.indexOf(gameId)<0){a.push(gameId);localStorage.setItem('j2me_seen',JSON.stringify(a.slice(0,500)));xpAdd(5);qInc('seen');}}
    if(kind==='download'&&gameId){xpAdd(10);try{localStorage.setItem('j2me_dl_total',String(+(localStorage.getItem('j2me_dl_total')||0)+1));}catch(e){}}
    if(kind==='fav'){xpAdd(3);qInc('fav');}
    if(kind==='comment'){xpAdd(15);qInc('cmt');try{localStorage.setItem('j2me_cmt_total',String(+(localStorage.getItem('j2me_cmt_total')||0)+1));}catch(e){}}
  }catch(e){}
}
function qInc(kind){
  try{
    const goals={seen:3,fav:1,cmt:1};
    if(!(kind in goals))return;
    const day=new Date().toISOString().slice(0,10);
    const k='j2me_q_'+kind+'_'+day, dk='j2me_qd_'+kind+'_'+day;
    const v=+(localStorage.getItem(k)||0)+1; localStorage.setItem(k,String(v));
    if(v>=goals[kind]&&!localStorage.getItem(dk)){localStorage.setItem(dk,'1');xpAdd(10);}
  }catch(e){}
}
// Nút cài app PWA (hiện khi trình duyệt cho phép)
let deferredPrompt=null;
window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();deferredPrompt=e;try{document.querySelectorAll('.pwa-install').forEach(function(b){b.style.display='';});}catch(err){}});
function installApp(){if(deferredPrompt){try{deferredPrompt.prompt();deferredPrompt=null;}catch(e){}}else{alert(cmtT('install_msg','Mở menu trình duyệt → "Thêm vào màn hình chính" để cài app.'));}}
// Bingo tuần + khóa tải: bảng Deterministic theo tuần (KHỚP senpai.js), helper đánh dấu tiến trình.
// Lưu ý: phút online của khách được server xác minh qua presence chain đã ký;
// like/phá đảo vẫn là số local (khóa mềm) — đủ chặn link copy tay qua proof.
function __bm(a){try{var W=__bw();var k='j2me_bingo_prog',o=JSON.parse(localStorage.getItem(k)||'{}');if(!o[W])o[W]={};if(!o[W][a]){o[W][a]=1;localStorage.setItem(k,JSON.stringify(o));}try{stEvent('bingo',a);}catch(_e){}}catch(e){}}
function __bw(d){d=d||new Date();var t=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate()));var day=(t.getUTCDay()+6)%7;t.setUTCDate(t.getUTCDate()-day+3);var f=new Date(Date.UTC(t.getUTCFullYear(),0,4));var fd=(f.getUTCDay()+6)%7;f.setUTCDate(f.getUTCDate()-fd+3);var w=1+Math.round((t-f)/6048e5);return t.getUTCFullYear()+'-W'+('0'+w).slice(-2);}
function __bboard(){
  var ids=['open_vi','spin','feed','play','adv','win','fav','share','comment','mail','battle','theme'];
  var h=2166136261,W=__bw(),i;
  for(i=0;i<W.length;i++){h^=W.charCodeAt(i);h=Math.imul(h,16777619);}
  var seed=h>>>0,pool=ids.slice(),out=[];
  var rnd=function(){seed|=0;seed=(seed+0x6D2B79F5)|0;var t=Math.imul(seed^(seed>>>15),1|seed);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};
  while(out.length<9&&pool.length)out.push(pool.splice(Math.floor(rnd()*pool.length),1)[0]);
  return out;
}
function __blines(){
  try{
    var board=__bboard(),W=__bw(),p=JSON.parse(localStorage.getItem('j2me_bingo_prog')||'{}')[W]||{};
    var done=function(id){if(p[id])return true;if(id==='fav'){try{var f=JSON.parse(localStorage.getItem('j2me_favs')||'[]');if(f.length)return true;}catch(e){}}return false;};
    var L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]],n=0,i;
    for(i=0;i<L.length;i++)if(done(board[L[i][0]])&&done(board[L[i][1]])&&done(board[L[i][2]]))n++;
    return n;
  }catch(e){return 0;}
}
function __petLv(){try{var s=JSON.parse(localStorage.getItem('j2me_senpai')||'null');if(s&&s.pet)return Math.floor((s.pet.exp||0)/100);}catch(e){}return 0;}
function __gate(g){
  var gt=g&&g.gate&&g.gate.type;
  if(!gt||gt==='none')return null;
  if(gt==='bingo'){var n=Math.max(1,parseInt((g.gate.lines||1),10)||1),has=__blines();return has>=n?null:{label:cmtT('g_gateBingo','Bingo tuần này'),need:cmtT('g_gateNeed','cần {n} line (đang có {h})').replace('{n}',n).replace('{h}',has)};}
  if(gt==='pet'){var nl=Math.max(1,parseInt(g.gate.level||3,10)||3),lv=__petLv();return lv>=nl?null:{label:cmtT('g_gatePet','Pet đạt Lv{n}').replace('{n}',nl),need:cmtT('g_gatePetHas','pet đang Lv{h}').replace('{h}',lv)};}
  if(gt==='badge'){try{var s2=JSON.parse(localStorage.getItem('j2me_senpai')||'null');if(s2&&s2.gacha&&s2.gacha.badges&&s2.gacha.badges.length)return null;}catch(e){}return{label:cmtT('g_gateBadge','Huy hiệu gacha hiếm'),need:cmtT('g_gateBadgeNeed','quay gacha ra huy hiệu đã')};}
  if(gt==='xp'){var x=0;try{var o=JSON.parse(localStorage.getItem('j2me_xp')||'{"xp":0}');x=o.xp||0;}catch(e){}var nx=Math.max(1,parseInt(g.gate.xp||100,10)||100);return x>=nx?null:{label:cmtT('g_gateXp','Tổng {n} XP').replace('{n}',nx),need:cmtT('g_gateXpHas','đang có {x} XP').replace('{x}',x)};}
  return null;
}
function __proof(g){
  try{
    var gid=g.id;
    var st={min:0,likes:0,done:0,names:[],read:0};
    try{st.min=stMinutes();}catch(e){}
    try{st.likes=stLikes();}catch(e){}
    try{st.done=stDone();}catch(e){}
    try{st.names=stNames();}catch(e){}
    try{st.read=stRead(gid);}catch(e){}
    var o={id:gid,day:new Date().toISOString().slice(0,10),lines:__blines(),st:st,read:st.read};
    try{var pr=stPresence();if(pr)o.presence=pr.tok;}catch(e){}
    try{if(typeof stCid==='function'){var _cid=stCid();if(_cid)o.cid=_cid;}}catch(e){}
    return btoa(unescape(encodeURIComponent(JSON.stringify(o)))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  }catch(e){return '';}
}
// --- Khóa tải kiểu stats: phút online / bình luận duyệt / like / phá đảo (gộp AND) ---
// Đã đăng nhập: hiển thị theo SỐ SERVER (ustats theo tài khoản) cho khớp với
// thứ server dùng để cấp vé; khách vãng lai: dùng presence chain + số local.
let __srvVals=null;
function __pullSrvVals(cb){
  __srvVals=null;
  var tk=''; try{tk=stToken();}catch(e){}
  if(!tk){ if(cb)cb(); return; }
  fetch(apiRoot()+'/api/ustats',{headers:{'Authorization':'Bearer '+tk},cache:'no-store'})
    .then(function(r){return r.ok?r.json():null;})
    .then(function(j){
      if(j&&typeof j.minutes==='number'){
        var num=function(v){return (typeof v==='number'&&isFinite(v))?v:0;};
        __srvVals={min:num(j.minutes),likes:num(j.likes),done:num(j.completed)};
      }
      if(cb)cb();
    }).catch(function(){ if(cb)cb(); });
}
function __statVals(){if(__srvVals)return __srvVals;var o={min:0,likes:0,done:0,read:0};try{o.min=stVerifiedMin();}catch(e){}try{o.likes=stLikes();}catch(e){}try{o.done=stDone();}catch(e){}try{var gid='';try{gid=getId();}catch(e){} o.read=stRead(gid);}catch(e){}return o;}
function __statsRows(g,apprN){
  var rq=(g.gate&&g.gate.require)||{},rows=[],v=__statVals();
  if(rq.read!=null){
    var have=v.read||0;
    var pct=Math.min(100, Math.floor(have*100/Math.max(1,rq.read)));
    rows.push({k:'r',need:+rq.read,has:have,ok:have>=+rq.read,label:cmtT('g_readReq','Đọc bài {n} giây').replace('{n}',rq.read),hint:'<small>'+cmtT('g_readWait','Đã đọc {s}/{n}s…').replace('{s}',have).replace('{n}',rq.read)+' <span style="display:inline-block;width:40px;height:4px;background:#e8f4fd;border-radius:4px;vertical-align:middle"><span style="display:block;width:'+pct+'%;height:100%;background:#0066cc;border-radius:4px"></span></span> <span style="font-size:10px">'+cmtT('g_readHint','cứ mở trang là tính giờ')+'</span></small>'});
  }
  if(rq.minutes!=null)rows.push({k:'m',need:+rq.minutes,has:v.min,ok:v.min>=+rq.minutes,label:cmtT('go_req_min','Online đủ {n} phút').replace('{n}',rq.minutes),hint:'<small>'+cmtT('go_auto','mở web là tự tính')+'</small>'});
  if(rq.likes!=null)rows.push({k:'l',need:+rq.likes,has:v.likes,ok:v.likes>=+rq.likes,label:cmtT('go_req_like','Thích {n} game').replace('{n}',rq.likes),hint:'<a href="'+apiRoot()+'/index.html" style="color:#0066cc">'+cmtT('go_likeNow','→ thích ngay')+'</a>'});
  if(rq.completed!=null)rows.push({k:'d',need:+rq.completed,has:v.done,ok:v.done>=+rq.completed,label:cmtT('go_req_done','Phá đảo {n} game').replace('{n}',rq.completed),hint:'<small>'+cmtT('go_doneHint','bấm "Phá đảo?" ở trang game')+'</small>'});
  return rows;
}
function __statsPass(rows){for(var i=0;i<rows.length;i++)if(!rows[i].ok)return false;return true;}
function __statsRowsHtml(rows){
  return rows.map(function(r){
    var ic=r.pending?'…':(r.ok?'✓':'✗'),cls=r.pending?'':(r.ok?'ok':'bad');
    var pr=r.pending?cmtT('go_checking2','đang kiểm tra...'):(r.has+'/'+r.need);
    return '<div class="lockrow '+cls+'"><span>'+ic+'</span><span>'+r.label+'</span><b>'+pr+'</b>'+(r.ok?'':(r.hint||''))+'</div>';
  }).join('');
}
// Live refresh hộp khóa trong modal: cập nhật số phút realtime (10s/lần),
// tự xin vé + sang trang tải ngay khi đủ điều kiện. Dừng khi đóng modal.
let __lockTimer=null, __lockAppr=null, __lockTick=0, __lockFailMin=0;
function __lockStop(){ try{ if(__lockTimer){ clearInterval(__lockTimer); __lockTimer=null; } }catch(e){} }
function __lockHead(){
  var hardNow=false; try{hardNow=stLogged();}catch(e){}
  return '🔒 <b>'+cmtT('g_cond','Chưa đủ điều kiện')+'</b>'
    +(hardNow?'':'<br><small><a href="'+apiRoot()+'/dang-nhap.html" style="color:#0066cc">'+cmtT('li_in','Đăng nhập')+'</a> '+cmtT('go_saveProg','để lưu tiến độ theo tài khoản')+'</small>');
}
function __lockPaint(msg,rows,head,foot){ try{ msg.innerHTML=(head||__lockHead())+'<div style="margin-top:6px;text-align:left">'+__statsRowsHtml(rows)+'</div>'+(foot||''); }catch(e){} }
function __lockLive(gid,gm,msg,res,head,foot){
  __lockStop(); __lockTick=0;
  __lockTimer=setInterval(function(){
    try{
      if(!document.body.contains(msg)||document.getElementById('dlModal').classList.contains('hidden')){ __lockStop(); return; }
      __lockTick++;
      var doPaint=function(){
        var rows=__statsRows(gm,__lockAppr);
        var paint=function(rr){
          __lockPaint(msg,rr,head,foot);
          if(__statsPass(rr)){ __lockStop(); msg.textContent=cmtT('g_getting','Đủ điều kiện! Đang lấy vé...'); __ticketAndGo(gid,res,msg,true); }
        };
        paint(rows);
      };
      // tick 1s realtime cho Đọc bài; server sync mỗi 30s
      if(__lockTick%30===0){ try{__pullSrvVals(doPaint);}catch(e){doPaint();} }
      else doPaint();
    }catch(e){}
  },1000);
}
function __ticketAndGo(gid,res,msgEl,wasPassing){
  __lockStop();
  msgEl.textContent=cmtT('g_ticket','Đang lấy vé tải...');
  var gm=(GAMES_MAP||{})[gid]||{id:gid};
  stFreshToken().then(function(_tk){
    var _hh={}; try{if(_tk)_hh={'Authorization':'Bearer '+_tk};}catch(e){}
    fetch(apiRoot()+'/api/ticket?id='+encodeURIComponent(gid)+'&res='+encodeURIComponent(res)+'&proof='+encodeURIComponent(__proof(gm)),{cache:'no-store',headers:_hh})
    .then(function(r){return r.json().then(function(j){return {st:r.status,j:j};});})
    .then(function(o){
      if(o.st===200&&o.j&&o.j.ticket){__lockFailMin=0;ECO.owned=true;try{ecoRender();}catch(e){}try{countDownload(gid);}catch(e2){}location.href=apiRoot()+'/go.html?ticket='+encodeURIComponent(o.j.ticket);}
      else if(o.st===402){
        var need=(o.j&&o.j.need)||ECO.cost, bal=(o.j&&typeof o.j.bal==='number')?o.j.bal:ECO.bal;
        ECO.retry=true; ECO.bal=bal;
        try{ecoRender();}catch(e){}
        var short=Math.max(0,need-bal);
        var acts='<div style="margin-top:8px;display:grid;gap:6px">'
          +'<button data-eco-comment="1" class="dl-btn" style="font-size:11px;justify-content:center">'+cmtT('g_actComment','💬 Bình luận game này (+5 EXP khi duyệt)')+'</button>';
        if(short>5) acts+='<small style="color:#4a7a9a">'+cmtT('g_actStreak','🔥 Giữ chuỗi điểm danh để nhận thưởng lớn')+'</small>';
        acts+='</div>';
        msgEl.innerHTML='🔒 <b>'+cmtT('g_cond','Chưa đủ điều kiện')+'</b> ('+cmtT('g_cost','Giá tải:')+' '+need+' EXP). '+cmtT('g_lowexp','Thiếu {n} EXP — điểm danh mỗi ngày để tích nhé').replace('{n}',short)+acts;
      }
      else if(o.st===403){
        var reason=(o.j&&o.j.reason)||'';
        // Hiển thị đủ mà vé vẫn rớt 'minutes' nhiều lần liên tiếp = chain cũ (đổi IP/dải mạng):
        // dừng auto-retry, hiện nút đếm lại thay vì kẹt 4/5, 32/5 mãi.
        if(reason==='minutes'&&wasPassing){__lockFailMin=(__lockFailMin||0)+1;}else{__lockFailMin=0;}
        if(__lockFailMin>=3){
          msgEl.innerHTML='🔒 <b>'+cmtT('g_cond','Chưa đủ điều kiện')+'</b> (<b>minutes</b>). '+cmtT('g_ipStuck','Mạng của bạn vừa đổi IP nên vé cũ không còn hiệu lực.')
            +'<div style="margin-top:8px;text-align:center"><button data-relock="1" class="dl-btn" style="font-size:11px">'+cmtT('g_recount','🔄 Đếm lại từ đầu')+'</button></div>';
          return;
        }
        var rs0=__statsRows(gm,null);var needC0=rs0.some(function(r){return r.k==='c';});var hd='🔒 <b>'+cmtT('g_cond','Chưa đủ điều kiện')+'</b>'+(reason?' (<b>'+escHtml(reason)+'</b>)':'')+'. '+cmtT('g_srv','Server vừa kiểm tra — số bên dưới là mới nhất:');var ft='<div style="margin-top:6px"><small>'+cmtT('g_hang','Treo trang thêm cho đủ rồi bấm Tải lại (không cần F5).')+'</small></div>';var paint=function(rr){__lockPaint(msgEl,rr,hd,ft);};__pullSrvVals(function(){var rs=__statsRows(gm,null);var nc=rs.some(function(r){return r.k==='c';});paint(rs);if(nc){try{stApprovedCount(function(n){__lockAppr=n;paint(__statsRows(gm,n));__lockLive(gid,gm,msgEl,res,hd,ft);});}catch(e){__lockLive(gid,gm,msgEl,res,hd,ft);}}else{__lockLive(gid,gm,msgEl,res,hd,ft);}});}
      else{msgEl.textContent=cmtT('g_noTicket2','Không lấy được vé (')+o.st+')'+((o.j&&o.j.error)?' ['+o.j.error+((o.j&&o.j.miss)?':'+o.j.miss:'')+']':'');}
    }).catch(function(){msgEl.textContent=cmtT('g_offline','Mất mạng, thử lại sau.');});
  }).catch(function(){msgEl.textContent=cmtT('g_offline','Mất mạng, thử lại sau.');});
}
async function renderDetail(){
  const qs=new URLSearchParams(location.search);
  let GAMES=null,id='',g=null,isPreview=false;
  if(qs.get('preview')==='1'){
    try{ g=JSON.parse(sessionStorage.getItem('game_preview')||'null'); }catch(e){ g=null; }
    if(!g||!g.name){ document.querySelector('.body-text').innerHTML='<p class="note">'+escHtml(cmtT('g_noPreview','Không có dữ liệu xem trước. Hãy bấm nút "Xem trước" trong trang admin.'))+'</p>'; return; }
    isPreview=true; id=g.id||'preview';
  }else{
    id=getId();
    try{const _em=document.getElementById('__GAME_DATA__');if(_em){const _g=JSON.parse(_em.textContent);if(_g&&_g.id===id){g=_g;GAMES={};GAMES[id]=_g;/* KHÔNG seed GAMES_MAP bằng 1 game: loadMap(force) phải tải full danh mục, nếu không related luôn rỗng và ghi đè HTML do server render */loadMap(true).then(function(m){GAMES=m;try{Object.assign(GAMES_MAP||{},m);}catch(e){}try{if(!isPreview)renderRelatedList();}catch(e){}}).catch(function(){});}}}catch(e){}
    if(!g){GAMES=await loadMap();g=GAMES[id];}
  }
  if(!g){const nf=document.querySelector('.kawaii-d')||document.querySelector('.wrap'); if(nf)nf.innerHTML=`<div style="padding:20px;text-align:center"><h1>${cmtT('g_notfound','Không tìm thấy game!')}</h1><p><a href="${apiRoot()}/index.html">${cmtT('back_home','‹ Về trang chủ')}</a></p></div>`; return;}
  if(!isPreview){try{xpBump('visit',id);}catch(e){}}
  if(!isPreview){try{if(g&&g.vi)__bm('open_vi');}catch(e){}}
  document.title=g.name+cmtT('g_titleMid',' - Tải Game Java ')+g.res[0]+' | J2ME.VERCEL.APP';
  const bc2=document.getElementById('bcName'); if(bc2) bc2.textContent=g.name;
  const can=document.querySelector('link[rel="canonical"]'); if(can) can.href=location.origin+`/game/${id}.html`;
  const ogUrl=document.querySelector('meta[property="og:url"]'); if(ogUrl) ogUrl.content=location.origin+`/game/${id}.html`;
  const ogTitle=document.querySelector('meta[property="og:title"]'); if(ogTitle) ogTitle.content=g.name+' - Game Java';
  const ogImg=document.querySelector('meta[property="og:image"]'); if(ogImg&&g.thumb) ogImg.content=g.thumb;
  try{const ogW=document.querySelector('meta[property="og:image:width"]'); if(ogW) ogW.content="600"; const ogH=document.querySelector('meta[property="og:image:height"]'); if(ogH) ogH.content="600"; const ogAlt=document.querySelector('meta[property="og:image:alt"]'); if(ogAlt) ogAlt.content=g.name;}catch(e){}
  const metaDesc=document.querySelector('meta[name="description"]');   if(metaDesc) metaDesc.content=cmtT('g_metaA','Tải ')+g.name+cmtT('g_metaB',' cho Java J2ME. ')+`${String(g.desc||'').replace(/\[credit\][\s\S]*?\[\/credit\]/gi,' ').slice(0,120)}`+cmtT('g_metaC',' Hỗ trợ ')+`${(g.res||[]).join(', ')}.`;
  if(!isPreview&&location.search.includes('id=')){ history.replaceState(null,'',apiRoot()+`/game/${id}.html`); }
  const bc=document.getElementById('bcName'); if(bc) bc.textContent=g.name;
  if(isPreview){document.getElementById('breadcrumb').insertAdjacentHTML('afterend','<p class="note">'+escHtml(cmtT('g_preview','ĐANG XEM TRƯỚC — bấm Lưu trong admin để đăng thật.'))+'</p>');}
  // detail-head (kèm ngày đăng nếu bài có lưu created_at)
  let dateStr='';
  try{ if(g.created_at){ const dd=new Date(g.created_at); if(!isNaN(dd)) dateStr=dd.toLocaleDateString('vi-VN',{day:'2-digit',month:'2-digit',year:'numeric'}); } }catch(e){}
  // Lượt tải thật từ api/stats (rớt thì dùng số tĩnh trong JSON)
  let dlCount=(typeof g.downloads==='number'&&g.downloads>0)?g.downloads:null;
  if(!isPreview){
    try{
      const sr=await fetch(apiRoot()+'/api/stats?id='+encodeURIComponent(id),{cache:'no-store'});
      if(sr.ok){const sj=await sr.json(); if(sj&&typeof sj.downloads==='number')dlCount=sj.downloads;}
    }catch(e){}
  }
  const head=document.querySelector('.detail-head');
  head.innerHTML=`<img src="${escHtml(g.thumb)}" alt="${escHtml(g.name)} thumb" width="84" height="84" decoding="async" fetchpriority="high"><div><h1>${escHtml(g.name)} ${g.hot?'<span style="background:#0066cc;color:#fff;font-size:8px;padding:2px 5px;border-radius:8px">HOT</span>':''} ${g.vi?'<span style="background:#0a9c4a;color:#fff;font-size:8px;padding:2px 5px;border-radius:8px">VIỆT HÓA</span>':''}</h1><table class="info-table"><tr><th>${cmtT('g_thr_genre','Thể loại')}</th><td><a href="${apiRoot()}/category.html?cat=${encodeURIComponent(g.cat||'')}" style="color:#0066cc">${escHtml(g.cat)}</a></td></tr><tr><th>${cmtT('g_thr_size','Dung lượng')}</th><td>${escHtml(g.size)}</td></tr><tr><th>${cmtT('g_thr_res','Màn hình')}</th><td>${(g.res||[]).map(r=>`<span class="res-tag">${escHtml(r)}</span>`).join(' ')}</td></tr>${dateStr?`<tr><th>${cmtT('g_thr_date','Ngày đăng')}</th><td>${dateStr}</td></tr>`:''}${dlCount!=null?`<tr><th>${cmtT('g_thr_dl','Lượt tải')}</th><td>${Number(dlCount).toLocaleString('vi-VN')}</td></tr>`:''}</table></div>`;
  // dl
  document.querySelector('.dl-grid').innerHTML=(g.res||[]).map(r=>`<div class="dl-option"><b>${escHtml(r)}</b><br><small style="color:#4a7a9a;font-size:10px">${escHtml(g.size)} • ${String(r).includes('240')?'QVGA':'QCIF'}</small><br><a href="${escHtml(apiRoot()+'/api/dl?id='+encodeURIComponent(g.id)+'&res='+encodeURIComponent(r))}" class="dl-btn" data-dl-btn="1" data-name="${escHtml(g.name)}" data-res="${escHtml(r)}">${cmtT('dl','⬇ Tải JAR')}</a></div>`).join('');
  // Ghi chú đọc bài dưới lưới tải
  try{
    var rn=document.getElementById('readNote');
    if(rn){
      var needRead=0;
      if(g.gate&&g.gate.type==='stats'&&g.gate.require&&g.gate.require.read) needRead=+g.gate.require.read;
      else if(g.read_secs) needRead=+g.read_secs;
      else needRead=10;
      // mặc định mọi game đều 10s (theo yêu cầu)
      rn.style.display='block';
      try{window.__READ_NEED=needRead;}catch(e){}
      var vol=(g.voluntary||{fog:1});
      var updRN=function(){
        try{
          var raw=(typeof stRead==='function'?stRead(id):0); var have=Math.min(raw,needRead);
          rn.textContent= raw>=needRead ? '✓ '+cmtT('g_readDone','Đã đọc đủ — bấm Tải để tiếp tục') : cmtT('g_readNote','Xem trang {n}s để mở khóa tải').replace('{n}',needRead)+' ('+have+'/'+needRead+'s)';
          // Kéo rèm nút Tải: disable cho đến khi đủ giây
          try{
            var btns=document.querySelectorAll('[data-dl-btn]');
            var pp=have/needRead;
            btns.forEach(function(b){
              b.style.opacity=0.45+0.55*pp;
              b.style.transform='translateY('+(8*(1-pp))+'px)';
              b.style.filter= raw>=needRead ? 'none' : 'grayscale(.3)';
              b.style.pointerEvents= raw>=needRead ? 'auto' : 'none';
            });
          }catch(e3){}
          // Sương mù: phủ cả văn bản (kể cả DIV mô tả), tiêu đề mở trước, nội dung + ảnh mở sau.
          // Bấm Thích được +50% tiến trình sương (chỉ sương, gate tải vẫn giữ nguyên).
          try{
            if(vol.fog){
              var liked=false; try{liked=(typeof favHas==='function'&&favHas(id));}catch(eL){}
              var fogHave=Math.min(needRead, have+(liked?Math.ceil(needRead/2):0));
              var fogDone=fogHave>=needRead;
              var fog=document.querySelector('.body-text');
              var pctEl=document.getElementById('fogPct'), tip=document.getElementById('fogTip');
              if(fog){
                if(!pctEl){pctEl=document.createElement('div');pctEl.id='fogPct';pctEl.style.cssText='position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(0,102,204,.85);color:#fff;padding:6px 12px;border-radius:20px;font-size:11px;font-weight:700;z-index:2;pointer-events:none;white-space:nowrap';fog.style.position='relative';fog.appendChild(pctEl);}
                if(!tip){tip=document.createElement('div');tip.id='fogTip';tip.style.cssText='display:none;margin-top:8px;background:linear-gradient(180deg,#fffbe6,#fff3c4);border:1.5px dashed #e6a800;border-radius:10px;padding:8px;font-size:11px;color:#7a5a00;text-align:center';tip.textContent=cmtT('g_fogTip','💡 Mẹo: bấm Thích ở trên để mở khóa sương mù nhanh hơn!');fog.parentNode.appendChild(tip);}
                var pct=Math.floor(fogHave*100/needRead);
                pctEl.style.display= fogDone ? 'none' : 'block';
                pctEl.textContent=cmtT('g_fogPct','Đang dọn sương {p}%').replace('{p}',pct);
                tip.textContent=cmtT('g_fogTip','💡 Mẹo: bấm Thích ở trên để mở khóa sương mù nhanh hơn!');
                tip.style.display= fogDone ? 'block' : 'none';
                var kids=Array.from(fog.children).filter(function(el){return el.id!=='fogPct';});
                if(!kids.length) kids=Array.from(fog.querySelectorAll('h3,p,.shot-grid'));
                kids.forEach(function(el){
                  var isDiv=(el.tagName==='DIV');
                  var thr=isDiv?needRead:Math.ceil(needRead/3);
                  var amt=fogHave>=thr?0:Math.max(0,5-Math.floor(fogHave*5/thr));
                  el.style.filter= amt<=0?'none':'blur('+amt+'px)';
                  el.style.transition='filter .6s';
                });
                if(fogDone) fog.style.filter='none';
                try{fog.querySelectorAll('.shot-img').forEach(function(im){im.style.pointerEvents=fogDone?'auto':'none';});}catch(e4){}
              }
            }else{
              var pe=document.getElementById('fogPct'); if(pe) pe.style.display='none';
              var tp=document.getElementById('fogTip'); if(tp) tp.style.display='none';
              var fb=document.querySelector('.body-text'); if(fb){fb.style.filter='none'; try{Array.from(fb.children).forEach(function(el){el.style.filter='none';});}catch(e7){} try{fb.querySelectorAll('.shot-img').forEach(function(im){im.style.pointerEvents='auto';});}catch(e6){}}
            }
          }catch(e2){}
        }catch(e){}
      };
      updRN();
      if(window._readNoteTimer) clearInterval(window._readNoteTimer);
      window._readNoteTimer=setInterval(updRN,1000);
    }
  }catch(e){}
  // Chia sẻ + QR + yêu thích
  try{
    const pageUrl=isPreview?location.href:('https://J2ME.VERCEL.APP/game/'+id+'.html');
    let shareBox=document.getElementById('shareBox');
    if(!shareBox){const de=document.querySelector('.kawaii-e'); if(de){shareBox=document.createElement('div');shareBox.id='shareBox';shareBox.className='kawaii-f';de.after(shareBox);}}
    if(shareBox){
      const favOn=favHas(id);
      shareBox.innerHTML=`<div class="kawaii-title">${cmtT('g_share','Chia sẻ')}</div><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">`
      +`<a href="https://zalo.me/share?url=${encodeURIComponent(pageUrl)}" target="_blank" rel="noopener" class="dl-btn" style="font-size:11px">Zalo</a>`
      +`<a href="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(pageUrl)}" target="_blank" rel="noopener" class="dl-btn" style="font-size:11px">Facebook</a>`
      +`<button id="copyLinkBtn" class="dl-btn" style="font-size:11px">${cmtT('g_copy','Copy link')}</button>`
      +`<button id="qrBtn" class="dl-btn" style="font-size:11px">${cmtT('g_qr','QR')}</button>`
      +`<button id="favBtn" class="dl-btn" style="font-size:11px">${favOn?cmtT('g_favOn','♥ Đã thích'):cmtT('g_favOff','♡ Thích')}</button>`
      +`<button id="doneBtn" class="dl-btn" style="font-size:11px">${(function(){try{return JSON.parse(localStorage.getItem('j2me_done')||'[]').indexOf(id)>=0;}catch(e){return false;}})()?cmtT('g_doneOn','✓ Đã phá đảo'):cmtT('g_doneOff','Phá đảo?')}</button></div>`
      +`<div id="qrWrap" style="display:none;text-align:center;margin-top:8px"><img id="qrImg" alt="QR mở trên điện thoại" width="160" height="160" style="width:160px;height:160px;border:2px solid #b8d8f8;border-radius:12px;background:#fff"><br><small style="color:#4a7a9a;font-size:10px">${cmtT('g_qrNote','Quét để mở trên điện thoại')}</small></div>`;
      document.getElementById('copyLinkBtn').onclick=function(){copyPageUrl(pageUrl,this);try{__bm('share');}catch(e){}};
      document.getElementById('qrBtn').onclick=function(){const w=document.getElementById('qrWrap');const im=document.getElementById('qrImg');if(w.style.display==='none'){if(!im.src)im.src='https://api.qrserver.com/v1/create-qr-code/?size=160x160&data='+encodeURIComponent(pageUrl);w.style.display='block';}else{w.style.display='none';}};
      document.getElementById('favBtn').onclick=function(){const on=favToggle(id);this.textContent=favHas(id)?cmtT('g_favOn','♥ Đã thích'):cmtT('g_favOff','♡ Thích');if(on){xpBump('fav');}};
      document.getElementById('doneBtn').onclick=function(){try{let a=JSON.parse(localStorage.getItem('j2me_done')||'[]');const has=a.indexOf(id)>=0;a=has?a.filter(function(x){return x!==id;}):a.concat([id]);localStorage.setItem('j2me_done',JSON.stringify(a.slice(0,500)));this.textContent=has?cmtT('g_doneOff','Phá đảo?'):cmtT('g_doneOn','✓ Đã phá đảo');try{stEvent(has?'uncomplete':'complete',id);}catch(e){}}catch(e){}};
    }
  }catch(e){}
  // body — lưới demo tự cân theo số lượng ảnh: 1 ảnh căn giữa khổ lớn, 2 ảnh chia đôi,
  // từ 3 ảnh trở lên 3 ảnh/hàng, hàng cuối lẻ tự căn giữa (flex + justify-content:center)
  const shots=(g.shots||[]);
  const shotCls=shots.length===1?' count-1':shots.length===2?' count-2':'';
  const shotsHtml=shots.length?`<div class="shot-grid${shotCls}">${shots.map((s,i)=>`<img src="${escHtml(s)}" alt="${cmtT('g_shotAlt','Ảnh demo ')}${i+1}" width="240" height="320" loading="lazy" decoding="async" data-idx="${i}" class="shot-img" style="cursor:pointer">`).join('')}</div>`:`<p class="note">${cmtT('g_noShots','Chưa có ảnh demo cho game này.')}</p>`;
  document.querySelector('.body-text').innerHTML=`<h3>${cmtT('g_intro','📝 Giới thiệu')}</h3><div style="white-space:pre-line">${renderDesc(g.desc||'')}</div><h3>${cmtT('g_shots','🖼️ Hình ảnh')}</h3>${shotsHtml}<h3>${cmtT('g_req','⚙️ Yêu cầu')}</h3><p style="font-size:13px">• <b>MIDP 2.0</b> • ${cmtT('g_thr_res','Màn hình')} <b>${escHtml((g.res||[]).join(', '))}</b> • Trống ≥<b>${escHtml(g.size)}</b> • Opera Mini</p>`;
  CURRENT_SHOTS=shots;
  document.querySelectorAll('.shot-img').forEach(img=>{
    img.addEventListener('click',()=>openLightbox(parseInt(img.dataset.idx,10)));
  });
  // related: cùng chuyên mục trước, thiếu mới bù game khác (ẩn khi xem trước).
  // Nếu full danh mục chưa tải xong thì GIỮ NGUYÊN HTML do server render, không ghi đè rỗng.
  function renderRelatedList(){
  const allGames=Object.values(GAMES||{}).filter(x=>x&&x.id!==g.id);
  if(!allGames.length) return;
  const sameCat=allGames.filter(x=>x.cat&&g.cat&&x.cat===g.cat);
  const restCat=allGames.filter(x=>!(x.cat&&g.cat&&x.cat===g.cat));
  const rel=sameCat.concat(restCat).slice(0,6);
  if(!rel.length) return;
  document.getElementById('relatedBox').style.display='block';
  document.getElementById('relatedGrid').innerHTML=rel.map(x=>`<a href="${apiRoot()}/game/${escHtml(x.id)}.html" style="background:#fff;border:1.5px solid #b8d8f8;border-radius:10px;padding:6px;text-align:center;text-decoration:none"><img src="${escHtml(x.thumb)}" width="48" height="48" loading="lazy" decoding="async" alt="${escHtml(x.name)}" style="width:48px;height:48px;border-radius:8px;margin:0 auto;object-fit:cover"><span style="font-size:10px;font-weight:700;display:block;color:#1a3a5c">${escHtml(String(x.name||'').split('[')[0].slice(0,14))}</span><small style="font-size:9px;color:#4a7a9a">${escHtml((x.res||[])[0]||'')}</small></a>`).join('');
  }
  if(!isPreview){try{renderRelatedList();}catch(e){}}
  if(!isPreview){ try{loadComments(id);}catch(e){} }
}
// Dùng chung 1 AudioContext (singleton) thay vì tạo mới mỗi lần -> tránh treo trình duyệt do vượt giới hạn AudioContext
let SHARED_AC=null;
function getAC(){
  try{
    if(!SHARED_AC) SHARED_AC=new (window.AudioContext||window.webkitAudioContext)();
    if(SHARED_AC.state==='suspended') SHARED_AC.resume().catch(()=>{});
    return SHARED_AC;
  }catch(e){ return null; }
}
function playClick(f=880,d=0.12,v=0.22){try{const c=getAC(); if(!c) return; const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=f;g.gain.value=v;o.connect(g);g.connect(c.destination);o.start();g.gain.exponentialRampToValueAtTime(0.0001,c.currentTime+d);o.stop(c.currentTime+d)}catch(e){}}
function playGlitch(){try{const c=getAC(); if(!c) return; const o=c.createOscillator(),g=c.createGain(),f=c.createBiquadFilter();o.type='square';o.frequency.value=120+Math.random()*300;f.type='bandpass';f.frequency.value=900;f.Q.value=8;g.gain.value=0.12;o.connect(f);f.connect(g);g.connect(c.destination);o.start();g.gain.exponentialRampToValueAtTime(0.0001,c.currentTime+0.18);o.stop(c.currentTime+0.18)}catch(e){}}
const ANIME_POOL=['/assets/anime-girl.webp','/assets/anime-1.webp','/assets/anime-2.webp','/assets/anime-3.webp','/assets/anime-4.webp','/assets/anime-5.webp','/assets/anime-6.webp','/assets/anime-7.webp','/assets/anime-8.webp'];
let pending={href:'#',name:'',res:''};
function doDownload(name,res){
  playClick(); const gid=getId(); const gm=(GAMES_MAP||{})[gid];
  try{ ecoLoad(ecoCost(gm||{}),gid||''); }catch(e){}
  const hasRes=!!(gm&&Array.isArray(gm.res)&&gm.res.indexOf(res)>=0);
  const gt=gm&&gm.gate&&gm.gate.type;
  const mc0=document.getElementById('modalConfirm');
  const msg=document.getElementById('modalMsg');
  if(!hasRes){pending={href:'#',gid:'',name:name,res:res};if(mc0)mc0.style.display='none';msg.textContent=cmtT('g_modalDemo','⚠ Link demo - vào admin.php nhập link thật nhé!');document.getElementById('dlModal').classList.remove('hidden');document.body.style.overflow='hidden';return false;}
  // Bài bắt đăng nhập (type login hoặc cờ login): chưa login thì chặn ngay ở modal
  var needLogin=!!(gm&&gm.gate&&(gt==='login'||gm.gate.login));
  var loggedNow=false; try{loggedNow=stLogged();}catch(e){}
  if(needLogin&&!loggedNow){
    pending={href:'#',gid:gid,name:name,res:res};
    if(mc0)mc0.style.display='none';
    msg.innerHTML=cmtT('g_memOnly','🔒 Bài này <b>chỉ dành cho thành viên</b>')+'<br><a href="'+apiRoot()+'/dang-nhap.html" style="color:#0066cc;font-weight:700">'+cmtT('g_loginNow','→ Đăng nhập ngay')+'</a><br><small style="color:#4a7a9a">'+cmtT('g_lockNote','1 tài khoản, mở khóa theo đúng cày của bạn (chống ké máy)')+'</small>';
    document.getElementById('dlModal').classList.remove('hidden');document.body.style.overflow='hidden';return false;
  }
  // Mọi link tải đều đi qua go.html bằng vé server (chống soi source/crack link)
  if(gt==='stats'){
    pending={href:'#',gid:gid,name:name,res:res};
    __lockAppr=null; __lockFailMin=0;
    if(mc0)mc0.style.display='none';
    msg.textContent=cmtT('go_checking2','Đang kiểm tra điều kiện...');
    document.getElementById('dlModal').classList.remove('hidden');document.body.style.overflow='hidden';
    var rows0=__statsRows(gm,null);
    var needCmt=rows0.some(function(r){return r.k==='c';});
    var show=function(rows){
      if(__statsPass(rows)){msg.textContent=cmtT('g_getting','Đủ điều kiện! Đang lấy vé...');__ticketAndGo(gid,res,msg);}
      else{__lockPaint(msg,rows);}
      __lockLive(gid,gm,msg,res);
    };
    var runShow=function(){
      if(needCmt){try{stApprovedCount(function(n){__lockAppr=n;show(__statsRows(gm,n));});}catch(e){show(__statsRows(gm,null));}}
      else show(__statsRows(gm,null));
    };
    // Vẽ khung ngay bằng số local, rồi đồng bộ số server (nếu đã đăng nhập) để khớp vé
    msg.innerHTML='<div style="text-align:left">'+__statsRowsHtml(rows0)+'</div>';
    try{__pullSrvVals(runShow);}catch(e){runShow();}
    return false;
  }
  const lock=gm?__gate(gm):null;
  if(lock){
    pending={href:'#',gid:gid,name:name,res:res};
    msg.innerHTML=cmtT('g_locked','🔒 Game bị khóa: ')+'<b>'+lock.label+'</b><br><small style="color:#4a7a9a">'+lock.need+'</small><br><a href="'+apiRoot()+'/goc-senpai.html" style="color:#0066cc;font-weight:700">'+cmtT('g_senpaiGo','→ Sang Góc Senpai làm nhiệm vụ')+'</a>';
    if(mc0)mc0.style.display='none';
    document.getElementById('dlModal').classList.remove('hidden'); document.body.style.overflow='hidden'; return false;
  }
  pending={href:'#',gid:gid,name:name,res:res}; if(mc0)mc0.style.display=''; msg.textContent=cmtT('g_confirmA','Bạn sắp tải ')+name+' ('+res+')'+cmtT('g_confirmB',' — bấm xác nhận để sang trang tải an toàn');
  const img=document.querySelector('.modal-anime-img'); if(img){const ch=ANIME_POOL[Math.floor(Math.random()*ANIME_POOL.length)]; img.style.display='block'; img.src=apiRoot()+ch;}
  const banner=document.querySelector('.modal-banner img'); if(banner){try{banner.src=(window.pickRandomBanner?window.pickRandomBanner():window.__BANNER_FALLBACK[Math.floor(Math.random()*window.__BANNER_FALLBACK.length)]);}catch(e){} if(window.getBannerList)window.getBannerList().then(function(list){try{banner.src=window.pickRandomBanner(list);}catch(e){}}).catch(function(){});}
  document.getElementById('modalConfirm').href='#'; document.getElementById('dlModal').classList.remove('hidden'); document.body.style.overflow='hidden'; return false;
}
// Ví EXP trong modal tải: số dư / giá / sở hữu / điểm danh (realtime, không reload)
let ECO={bal:0,checked:false,streak:0,owned:false,cost:0,ready:false,retry:false};
function ecoCost(gm){var v=parseInt(gm&&(gm.dl_cost),10);return (typeof v==='number'&&isFinite(v))?Math.max(0,Math.min(100000,v)):10;}
function ecoAuth(){var h={};try{if(stToken())h={'Authorization':'Bearer '+stToken()};}catch(e){}var cid='';try{if(typeof stCid==='function')cid=stCid()||'';}catch(e){}return {h:h,cid:cid};}
function ecoRender(){
  var box=document.getElementById('ecoBox'); if(!box) return;
  var h='<div style="background:#fffbe6;border:1.5px dashed #e6a800;border-radius:10px;padding:7px 10px;font-size:11px;line-height:1.7;margin-top:8px">⚡ <b>'+ECO.bal+'</b> EXP';
  if(ECO.owned) h+=' • '+cmtT('g_owned','Đã sở hữu — tải lại miễn phí');
  else if(ECO.cost>0) h+=' • '+cmtT('g_cost','Giá tải:')+' <b>'+ECO.cost+'</b> EXP';
  else h+=' • '+cmtT('g_dlFree','Tải miễn phí');
  if(ECO.streak>1) h+='<br><small>'+cmtT('g_streak','🔥 Chuỗi {n} ngày').replace('{n}',ECO.streak)+'</small>';
  h+='<br>';
  if(ECO.checked) h+='<small>'+cmtT('g_checked','Đã điểm danh hôm nay ✓')+'</small>';
  else h+='<button id="ecoCheckBtn" class="dl-btn" style="font-size:11px;padding:6px 14px">'+cmtT('g_checkin','🎲 Điểm danh hôm nay')+'</button>';
  h+='</div>';
  box.innerHTML=h;
  var b=document.getElementById('ecoCheckBtn'); if(b) b.onclick=function(){ecoCheckin();};
}
function ecoEnsureBox(){
  var box=document.getElementById('ecoBox');
  if(!box){
    var msg=document.getElementById('modalMsg');
    if(!msg) return null;
    box=document.createElement('div'); box.id='ecoBox';
    msg.after(box);
    box=document.getElementById('ecoBox');
  }
  return box;
}
function ecoLoad(cost,gid){
  ECO.cost=cost; ECO.ready=false; ECO.retry=false;
  try{ if(!ecoEnsureBox()) return; }catch(e){ return; }
  ecoRender();
  var a=ecoAuth();
  stFreshToken().then(function(_tk){
    var hh={}; try{for(var k in a.h)hh[k]=a.h[k];}catch(e){}
    try{if(_tk)hh['Authorization']='Bearer '+_tk;}catch(e){}
    fetch(apiRoot()+'/api/economy?cid='+encodeURIComponent(a.cid),{headers:hh,cache:'no-store'})
    .then(function(r){return r.ok?r.json():null;})
    .then(function(j){
      if(!j){try{var bb=document.getElementById('ecoCheckBtn');if(bb){bb.disabled=false;bb.textContent=cmtT('g_netRetry','⚠️ Lỗi mạng, bấm lại');}}catch(e){} return;}
      ECO.bal=+(j.bal||0); ECO.checked=!!j.checked; ECO.streak=+(j.streak||0);
      ECO.owned=!!(j.owned&&j.owned.indexOf(gid)>=0); ECO.ready=true;
      ecoRender();
    }).catch(function(){try{var bb2=document.getElementById('ecoCheckBtn');if(bb2){bb2.disabled=false;bb2.textContent=cmtT('g_netRetry','⚠️ Lỗi mạng, bấm lại');}}catch(e){}});
  }).catch(function(){});
}
function ecoCheckin(){
  var b=document.getElementById('ecoCheckBtn'); if(b){b.disabled=true;b.textContent='…';}
  var a=ecoAuth();
  var hh={'Content-Type':'application/json'};
  try{var _tk00=stToken();if(_tk00)hh['Authorization']='Bearer '+_tk00;}catch(e){}
  stFreshToken().then(function(_tk){
    try{if(_tk)hh['Authorization']='Bearer '+_tk;}catch(e){}
    fetch(apiRoot()+'/api/economy',{method:'POST',headers:hh,body:JSON.stringify({op:'checkin',cid:a.cid,sbt:(function(){try{return stToken();}catch(e){return '';}})()})})
    .then(function(r){return r.json().then(function(j){return {st:r.status,j:j};});})
    .then(function(o){
      var j=o.j||{};
      if(j&&typeof j.bal==='number'){ECO.bal=j.bal;}
      if(j&&(j.ok||j.reason==='done')){ECO.checked=true;ECO.streak=+(j.streak||ECO.streak);}
      ECO.ready=true;
      ecoRender();
      if(j&&j.ok){
        var msg=document.getElementById('modalMsg');
        if(msg)msg.textContent=cmtT('g_got','🎲 +{n} EXP!').replace('{n}',j.got||0);
        // Điểm danh xong mà modal đang kẹt thiếu EXP và giờ đã đủ -> tự chạy tiếp
        try{
          if(ECO.retry&&!document.getElementById('dlModal').classList.contains('hidden')&&pending&&pending.gid&&pending.res&&(ECO.owned||ECO.bal>=ECO.cost)){
            ECO.retry=false;
            __ticketAndGo(pending.gid,pending.res,document.getElementById('modalMsg'));
          }
        }catch(e){}
      }
    })
    .catch(function(){ecoRender();try{var bb3=document.getElementById('ecoCheckBtn');if(bb3){bb3.disabled=false;bb3.textContent=cmtT('g_netRetry','⚠️ Lỗi mạng, bấm lại');}}catch(e){}});
    }).catch(function(){ecoRender();});
}
// Nút tải render động dùng data-attr (không inline onclick → tránh XSS qua tên game)
document.addEventListener('click',function(e){const b=e.target&&e.target.closest?e.target.closest('[data-dl-btn]'):null; if(!b) return; e.preventDefault(); try{doDownload(b.dataset.name||'',b.dataset.res||'');}catch(err){}});
(function(){
  const modal=document.getElementById('dlModal');
  const close=()=>{
    try{ playClick(520,0.1,0.15); }catch(e){}
    try{ if(typeof __lockStop==='function') __lockStop(); }catch(e){}
    try{ __lockFailMin=0; }catch(e){}
    modal.classList.add('hidden');
    document.body.style.overflow='';
  };
  document.getElementById('modalClose')?.addEventListener('click',close);
  document.getElementById('modalCancel')?.addEventListener('click',close);
  modal?.addEventListener('click',e=>{if(e.target===modal)close()});
  document.addEventListener('keydown',e=>{ if(e.key==='Escape' && !modal.classList.contains('hidden')) close(); });
  document.querySelector('.modal-anime')?.addEventListener('mouseenter',()=>{ try{ playGlitch(); }catch(e){} });
  document.getElementById('modalConfirm')?.addEventListener('click',e=>{
    e.preventDefault();
    const p=pending;
    if(!p||!p.gid||!p.res){
      document.getElementById('modalMsg').textContent=cmtT('g_modalDemo','⚠ Link demo - vào admin.php nhập link thật nhé!');
      setTimeout(close,1400);
      return;
    }
    try{ playClick(1040,0.14,0.25); }catch(e){}
    // Mọi link tải đều qua go.html: xin vé server rồi chuyển trang (chống crack/soi source)
    __ticketAndGo(p.gid,p.res,document.getElementById('modalMsg'));
  });
})();
// Bình luận + đánh giá sao (phân trang 5/trang + realtime polling, giữ nguyên trang đang xem)
let CMT_PAGE=1; const CMT_LIMIT=5; let CMT_GAME=''; let CMT_TOTAL=0, CMT_PAGES=1, CMT_TIMER=null, CMT_KNOWN=0;
function cmtT(k,fb){ try{ if(window.I18N&&window.I18N.t){const v=window.I18N.t(k); if(v&&v!==k) return v;} }catch(e){} return fb; }
// Hiển thị rõ ngày/tháng/năm - giờ:phút (vd: 20/09/2026 - 14:05)
function fmtDT(iso){ try{ const dt=new Date(iso); if(isNaN(dt)) return ''; const p=function(n){return String(n).padStart(2,'0');}; return p(dt.getDate())+'/'+p(dt.getMonth()+1)+'/'+dt.getFullYear()+' - '+p(dt.getHours())+':'+p(dt.getMinutes()); }catch(e){ return ''; } }
async function loadComments(gameId, page){
  const box=document.getElementById('cmtBox'); if(!box) return;
  box.style.display='block';
  CMT_GAME=gameId; if(page) CMT_PAGE=page;
  try{ window.CMT_GAME=CMT_GAME; window.CMT_PAGE=CMT_PAGE; }catch(e){}
  try{var _cn=document.getElementById('cmtName');if(_cn&&!_cn.value){var _nm=stNames();if(_nm.length)_cn.value=_nm[_nm.length-1];}}catch(e){}
  const sum=document.getElementById('cmtSummary'), list=document.getElementById('cmtList'), msg=document.getElementById('cmtMsg');
  const pager=document.getElementById('cmtPager');
  sum.textContent=cmtT('cmt_loading','Đang tải bình luận...'); list.innerHTML=''; msg.textContent='';
  if(pager) pager.innerHTML='';
  try{
    const r=await fetch(apiRoot()+'/api/comments?game='+encodeURIComponent(gameId)+'&page='+CMT_PAGE+'&limit='+CMT_LIMIT,{cache:'no-store'});
    if(!r.ok) throw new Error(r.status);
    const j=await r.json();
    CMT_TOTAL=j.total||0; CMT_PAGES=j.pages||1; CMT_PAGE=j.page||1;
    if(CMT_KNOWN===0) CMT_KNOWN=CMT_TOTAL;
    sum.innerHTML=CMT_TOTAL?('★ <b>'+escHtml(String(j.avg))+'</b> — '+CMT_TOTAL+' '+cmtT('cmt_reviews','đánh giá')+' — '+cmtT('cmt_page','trang')+' '+CMT_PAGE+'/'+CMT_PAGES):cmtT('cmt_empty','Chưa có đánh giá nào. Hãy là người đầu tiên!');
    window._cmtReplyTo=null;
    const replyLbl=cmtT('cmt_reply','↳ Trả lời');
    const itemHtml=function(c,reply){
      const st=reply?'':('<div class="stars">'+'★'.repeat(c.stars)+'☆'.repeat(5-c.stars)+'</div>');
      return '<div class="cmt-item"'+(reply?' style="margin:6px 0 0 18px;border-style:dashed"':'')+'>'+st+'<b>'+escHtml(c.name)+'</b> <small>'+escHtml(fmtDT(c.created_at))+'</small><div>'+escHtml(c.text)+'</div>'
      +(reply?'':'<div><button data-reply="'+escHtml(c.id)+'" data-rname="'+escHtml(c.name)+'" style="background:none;border:none;color:#0066cc;font-size:11px;cursor:pointer;padding:0">'+escHtml(replyLbl)+'</button></div>')+'</div>';
    };
    list.innerHTML=(j.comments||[]).map(function(c){
      return itemHtml(c,false)+((c.replies||[]).map(function(x){return itemHtml(x,true);}).join(''));
    }).join('') || ('<p class="note">'+escHtml(cmtT('cmt_empty_page','Trang này chưa có bình luận.'))+'</p>');
    list.querySelectorAll('[data-reply]').forEach(function(b){
      b.onclick=function(){
        window._cmtReplyTo={id:b.getAttribute('data-reply'),name:b.getAttribute('data-rname')};
        let tag=document.getElementById('replyTag');
        if(!tag){tag=document.createElement('div');tag.id='replyTag';tag.style.cssText='font-size:11px;color:#0066cc';form.insertBefore(tag,form.firstChild);}
        tag.innerHTML=cmtT('cmt_replying','Đang trả lời')+' <b></b> <a href="#" id="replyCancel" style="color:#4a7a9a">[hủy]</a>';
        tag.querySelector('b').textContent=window._cmtReplyTo.name;
        tag.querySelector('#replyCancel').onclick=function(e){e.preventDefault();window._cmtReplyTo=null;tag.remove();};
        document.getElementById('cmtText').focus();
      };
    });
    if(pager&&CMT_PAGES>1){
      const btn=function(label,pg,dis){return '<button data-pg="'+pg+'" '+(dis?'disabled':'')+' style="background:'+(String(pg)===String(CMT_PAGE)?'#0066cc':'#fff')+';color:'+(String(pg)===String(CMT_PAGE)?'#fff':'#0066cc')+';border:1.5px solid #81c7f0;border-radius:14px;padding:4px 10px;font-size:11px;font-weight:700;cursor:'+(dis?'default':'pointer')+';opacity:'+(dis?'.5':'1')+'">'+label+'</button>';};
      let h=btn('«',CMT_PAGE-1,CMT_PAGE<=1);
      for(let p=1;p<=CMT_PAGES;p++){ if(CMT_PAGES>7&&Math.abs(p-CMT_PAGE)>2&&(p!==1&&p!==CMT_PAGES)) continue; h+=btn(String(p),p,false); }
      h+=btn('»',CMT_PAGE+1,CMT_PAGE>=CMT_PAGES);
      pager.innerHTML=h;
      pager.querySelectorAll('[data-pg]').forEach(function(b){ b.onclick=function(){ const pg=parseInt(b.getAttribute('data-pg'),10); if(pg>=1&&pg<=CMT_PAGES&&pg!==CMT_PAGE){ CMT_PAGE=pg; try{window.CMT_PAGE=pg;}catch(e){} loadComments(CMT_GAME,pg); } }; });
    }
    const hint=document.getElementById('cmtNewHint'); if(hint) hint.style.display='none';
    startCmtPolling();
  }catch(e){ sum.textContent=String((e&&e.message)||'').indexOf('403')>=0?cmtT('cmt_403','Không tải được bình luận (bị chặn 403).'):cmtT('cmt_err','Không tải được bình luận lúc này.'); }
  const form=document.getElementById('cmtForm');
  form.onsubmit=function(ev){
    ev.preventDefault();
    msg.textContent=cmtT('cmt_sending','Đang gửi...');
    try{const last=+localStorage.getItem('cmt_last')||0; if(Date.now()-last<5*60*1000){msg.textContent=cmtT('cmt_fast','Bạn gửi quá nhanh, thử lại sau vài phút.');return;}}catch(e){}
    const payload={game:gameId,name:document.getElementById('cmtName').value,stars:document.getElementById('cmtStars').value,text:document.getElementById('cmtText').value,website:document.getElementById('cmtWeb').value,sbt:''};
    if(window._cmtReplyTo&&window._cmtReplyTo.id)payload.replyTo=window._cmtReplyTo.id;
    // Refresh token trước khi gửi để server nhận đúng tài khoản (lấy +5 EXP / đếm duyệt)
    stFreshToken().then(function(tk){ payload.sbt=tk||'';
    fetch(apiRoot()+'/api/comments',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
      .then(function(r){return r.text().then(function(t){let j={};try{j=JSON.parse(t);}catch(e){}return {st:r.status,j:j};});})
      .then(function(o){
        if(o.st===200&&o.j.ok){msg.textContent=cmtT('cmt_sent','Đã gửi! Bình luận hiện sau khi admin duyệt.')+(o.j.xpBonus?' (+5 EXP)':(o.j.auth==='stale'?' ('+cmtT('g_relogin','Phiên hết hạn — đăng nhập lại để nhận EXP')+')':(o.j.xpReason==='no_uid'?' ('+cmtT('g_loginBonus','Đăng nhập để nhận +5 EXP khi bình luận')+')':'')));document.getElementById('cmtText').value='';window._cmtReplyTo=null;const tg=document.getElementById('replyTag');if(tg)tg.remove();try{localStorage.setItem('cmt_last',String(Date.now()));}catch(e){}try{xpBump('comment');}catch(e){}try{__bm('comment');}catch(e){}try{stSaveName(document.getElementById('cmtName').value);}catch(e){}try{_stApprCache={at:0,n:-1};}catch(e){}try{if(o.j.xpBonus)ECO.bal+=5;}catch(e){}}
        else if(o.st===503){msg.textContent=cmtT('cmt_nohost','Chức năng bình luận chưa được bật trên hosting này.');}
        else if(o.st===429){msg.textContent=cmtT('cmt_fast','Bạn gửi quá nhanh, thử lại sau vài phút.');}
        else if(o.st===403){msg.textContent=cmtT('cmt_403post','Bị chặn (403): tải lại trang rồi gửi lại.');}
        else{var _e=(o.j&&o.j.error)||'';if(_e==='cross-origin denied')_e=cmtT('cmt_cross','bị chặn cross-origin, tải lại trang rồi thử lại');msg.textContent=cmtT('cmt_errPre','Lỗi: ')+(_e||cmtT('cmt_code','mã {s}, thử lại sau').replace('{s}',o.st));}
      })
      .catch(function(){msg.textContent=cmtT('cmt_neterr','Không gửi được. Kiểm tra mạng rồi thử lại.');});
    }).catch(function(){msg.textContent=cmtT('cmt_neterr','Không gửi được. Kiểm tra mạng rồi thử lại.');});
  };
}
function startCmtPolling(){
  try{ if(CMT_TIMER) clearInterval(CMT_TIMER); }catch(e){}
  CMT_TIMER=setInterval(async function(){
    try{
      if(document.hidden||!CMT_GAME) return;
      const r=await fetch(apiRoot()+'/api/comments?game='+encodeURIComponent(CMT_GAME)+'&page=1&limit=1',{cache:'no-store'});
      if(!r.ok) return;
      const j=await r.json();
      if(typeof j.total==='number'&&j.total!==CMT_KNOWN){
        if(CMT_PAGE===1){ CMT_KNOWN=j.total; loadComments(CMT_GAME,1); }
        else{ const h=document.getElementById('cmtNewHint'); if(h) h.style.display=''; }
      }
    }catch(e){}
  },15000);
  try{ document.getElementById('cmtReloadBtn').onclick=function(){ CMT_KNOWN=0; CMT_PAGE=1; loadComments(CMT_GAME,1); }; }catch(e){}
}
// Cảnh báo trước khi mở link ngoài trong mô tả
document.addEventListener('click',function(e){
  const a=e.target&&e.target.closest?e.target.closest('.body-text a[target="_blank"]'):null;
  if(!a) return;
  e.preventDefault();
  document.getElementById('extUrl').textContent=a.href;
  document.getElementById('extGo').href=a.href;
  document.getElementById('extModal').classList.remove('hidden');
  document.body.style.overflow='hidden';
});
(function(){
  const m=document.getElementById('extModal'); if(!m) return;
  const close=function(){m.classList.add('hidden');document.body.style.overflow='';};
  document.getElementById('extBack')?.addEventListener('click',close);
  m.addEventListener('click',function(e){if(e.target===m)close();});
  document.getElementById('extGo')?.addEventListener('click',close);
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!m.classList.contains('hidden'))close();});
})();
if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',function(){try{renderDetail();}catch(e){console.error(e);}});}else{try{renderDetail();}catch(e){console.error(e);}}
// Vẽ lại các thẻ động (chi tiết/chia sẻ/bình luận/ví) khi i18n sẵn sàng / đổi ngôn ngữ
document.addEventListener('i18n-ready',function(){
  try{
    if(!(window.I18N&&I18N.lang&&I18N.lang()!=='vi')) return;
    if(typeof renderDetail==='function'){ renderDetail(); }
  }catch(e){}
  try{ if(document.getElementById('ecoBox')&&typeof ecoRender==='function'){ ecoRender(); } }catch(e){}
});


(function(){function paint(){try{var on=document.documentElement.classList.contains('lite');var b=document.getElementById('liteToggle');if(b)b.textContent=on?'📶 Đủ':'📴 Nhẹ';}catch(e){}}try{var b=document.getElementById('liteToggle');if(b)b.onclick=function(){try{var h=document.documentElement;if(h.classList.contains('lite')){h.classList.remove('lite');localStorage.setItem('j2me_lite','0');}else{h.classList.add('lite');localStorage.setItem('j2me_lite','1');}paint();}catch(e){}};paint();}catch(e){}})();
try{document.querySelectorAll('.js-year').forEach(function(el){el.textContent=new Date().getFullYear();});}catch(e){}

// CSP strict: handle pwa-install without inline onclick
try{document.addEventListener('click',function(e){var b=e.target&&e.target.closest?e.target.closest('.pwa-install'):null; if(b){e.preventDefault(); try{installApp();}catch(err){}}});}catch(e){}
