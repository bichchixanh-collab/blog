# Patch notes — blog-2309

## Fixed
- `api/_sb.js`: `getUserStats()` now reads `bingo` and `pet_xp`, preventing those server-side stats from being reset/ignored during events and hard gates.
- `api/_rate.js` + `api/dl.js`: download tickets are now consumed once with Redis `SET NX` when Upstash is configured; local/dev falls back to process memory.
- `scripts/migrate-to-supabase.js`: fixed the `err`/`error` bug, fixed the transform input bug, and uses table-appropriate conflict keys. `user_stats` uses `uid` to match the runtime API.
- Added `package.json` and `scripts/check-syntax.mjs`.

## Important deployment note
The original ZIP did not contain an `assets/` directory even though the HTML references `/assets/...`. This patch does not fabricate or replace those design assets. Copy the original project's `assets/` directory into the repository before deploying if it exists outside this ZIP.

## Production requirement
For true one-time ticket semantics across Vercel instances/cold starts, configure `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN`. Without Upstash, one-time ticket state is only process-local.
